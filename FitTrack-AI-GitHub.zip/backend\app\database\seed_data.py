from sqlalchemy.orm import Session
from app.database.connection import SessionLocal, engine, Base
from app.models.schema import User, UserProfile, Exercise, FoodItem, WorkoutLog, MealLog, ProgressLog
from app.auth.security import get_password_hash

def seed_database():
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()

    # Seed Admin & Demo Users
    admin_user = db.query(User).filter(User.email == "admin@fittrack.com").first()
    if not admin_user:
        admin_user = User(
            email="admin@fittrack.com",
            hashed_password=get_password_hash("admin123"),
            full_name="System Admin",
            role="admin"
        )
        db.add(admin_user)

    demo_user = db.query(User).filter(User.email == "demo@fittrack.com").first()
    if not demo_user:
        demo_user = User(
            email="demo@fittrack.com",
            hashed_password=get_password_hash("demo123"),
            full_name="Alex Johnson",
            role="user"
        )
        db.add(demo_user)
        db.commit()
        db.refresh(demo_user)

        # Demo Profile
        demo_profile = UserProfile(
            user_id=demo_user.id,
            age=26,
            gender="male",
            height_cm=178.0,
            weight_kg=78.0,
            target_weight_kg=72.0,
            fitness_goal="fat_loss",
            fitness_level="intermediate",
            workout_preference="gym",
            equipment="full_gym",
            days_per_week=5,
            duration_mins=60,
            dietary_preference="non_vegetarian",
            food_cuisine_preference="indian",
            activity_level="moderate",
            bmi=24.6,
            bmr=1740.0,
            tdee=2697.0,
            daily_calorie_target=2247,
            protein_target_g=156,
            carbs_target_g=220,
            fats_target_g=62,
            water_target_ml=3200,
            streak_count=7,
            points=350
        )
        db.add(demo_profile)

        # Demo Progress Logs
        progress_data = [
            ("2026-07-01", 82.0, 22.0, 102.0, 88.0, 36.0, 58.0),
            ("2026-07-07", 81.2, 21.5, 101.5, 87.2, 36.2, 57.8),
            ("2026-07-14", 80.1, 20.8, 101.0, 86.0, 36.5, 57.5),
            ("2026-07-21", 79.0, 20.0, 100.5, 85.0, 37.0, 57.0),
            ("2026-07-27", 78.0, 19.4, 100.0, 84.0, 37.2, 56.5)
        ]
        for dt, w, bf, c, wa, a, th in progress_data:
            db.add(ProgressLog(
                user_id=demo_user.id, date=dt, weight_kg=w, body_fat_pct=bf,
                chest_cm=c, waist_cm=wa, arms_cm=a, thighs_cm=th
            ))

    # Seed Exercise Database
    if db.query(Exercise).count() == 0:
        exercises = [
            # Chest
            Exercise(name="Barbell Bench Press", category="Chest", muscle_group="Chest", equipment="Barbell", difficulty="Intermediate", instructions="Lie flat on bench, lower barbell to mid-chest, press up explosively."),
            Exercise(name="Incline Dumbbell Press", category="Chest", muscle_group="Upper Chest", equipment="Dumbbells", difficulty="Intermediate", instructions="Adjust bench to 30 degrees, press dumbbells upward focusing on upper chest."),
            Exercise(name="Push-Ups", category="Chest", muscle_group="Chest", equipment="Bodyweight", difficulty="Beginner", instructions="Keep body in straight line, lower chest near ground and push up."),
            Exercise(name="Cable Chest Fly", category="Chest", muscle_group="Inner Chest", equipment="Cable", difficulty="Intermediate", instructions="Bring handles together in hugging motion, squeezing inner chest."),

            # Back
            Exercise(name="Barbell Deadlift", category="Back", muscle_group="Lower Back / Glutes", equipment="Barbell", difficulty="Advanced", instructions="Keep back flat, drive through heels and extend hips."),
            Exercise(name="Lat Pulldown", category="Back", muscle_group="Lats", equipment="Cable Machine", difficulty="Beginner", instructions="Pull bar down to upper chest while squeezing shoulder blades together."),
            Exercise(name="Bent-Over Dumbbell Row", category="Back", muscle_group="Mid Back", equipment="Dumbbell", difficulty="Intermediate", instructions="Hinge at hips, pull dumbbell to ribcage with control."),
            Exercise(name="Pull-Ups", category="Back", muscle_group="Lats & Upper Back", equipment="Bodyweight", difficulty="Intermediate", instructions="Grip pull-up bar, pull chest toward bar."),

            # Shoulders
            Exercise(name="Overhead Dumbbell Press", category="Shoulders", muscle_group="Deltoids", equipment="Dumbbells", difficulty="Intermediate", instructions="Press dumbbells straight overhead without arching lower back."),
            Exercise(name="Dumbbell Lateral Raise", category="Shoulders", muscle_group="Side Delts", equipment="Dumbbells", difficulty="Beginner", instructions="Raise dumbbells out to sides until parallel to floor."),
            Exercise(name="Face Pulls", category="Shoulders", muscle_group="Rear Delts", equipment="Cable Machine", difficulty="Beginner", instructions="Pull rope handle toward forehead, flare elbows back."),

            # Arms
            Exercise(name="Dumbbell Bicep Curl", category="Arms", muscle_group="Biceps", equipment="Dumbbells", difficulty="Beginner", instructions="Keep upper arms fixed, curl weights toward shoulders."),
            Exercise(name="Tricep Rope Pushdown", category="Arms", muscle_group="Triceps", equipment="Cable Machine", difficulty="Beginner", instructions="Push rope down, spread rope ends at bottom."),
            Exercise(name="Hammer Curls", category="Arms", muscle_group="Brachialis", equipment="Dumbbells", difficulty="Beginner", instructions="Neutral grip curls targeting forearm and bicep thickness."),

            # Legs
            Exercise(name="Barbell Back Squat", category="Legs", muscle_group="Quadriceps & Glutes", equipment="Barbell", difficulty="Intermediate", instructions="Squat deep keeping knees tracking over toes."),
            Exercise(name="Leg Press", category="Legs", muscle_group="Quadriceps", equipment="Machine", difficulty="Beginner", instructions="Press footplate away with legs without locking knees."),
            Exercise(name="Romanian Deadlift", category="Legs", muscle_group="Hamstrings", equipment="Barbell / Dumbbells", difficulty="Intermediate", instructions="Hinge hips back feeling hamstring stretch."),
            Exercise(name="Walking Lunges", category="Legs", muscle_group="Glutes & Legs", equipment="Dumbbells / Bodyweight", difficulty="Beginner", instructions="Step forward into 90-degree lunge position."),
            Exercise(name="Standing Calf Raise", category="Legs", muscle_group="Calves", equipment="Machine / Bodyweight", difficulty="Beginner", instructions="Raise up on toes, pause at peak contraction."),

            # Core & Cardio
            Exercise(name="Plank Hold", category="Core", muscle_group="Abs", equipment="Bodyweight", difficulty="Beginner", instructions="Hold rigid isometric plank position for time."),
            Exercise(name="Hanging Leg Raise", category="Core", muscle_group="Lower Abs", equipment="Bodyweight", difficulty="Intermediate", instructions="Hang from bar, raise straight legs to waist level."),
            Exercise(name="Treadmill HIIT Sprints", category="Cardio", muscle_group="Cardiovascular System", equipment="Treadmill", difficulty="Intermediate", instructions="Alternate 30-sec max effort sprint with 30-sec recovery walk.")
        ]
        db.add_all(exercises)

    # Seed Food Database
    if db.query(FoodItem).count() == 0:
        foods = [
            # Protein Sources
            FoodItem(name="Chicken Breast (Grilled)", category="Protein", cuisine="Global", is_vegetarian=False, serving_size="100g", calories=165, protein_g=31.0, carbs_g=0.0, fats_g=3.6),
            FoodItem(name="Whole Eggs", category="Protein", cuisine="Global", is_vegetarian=False, serving_size="2 eggs (100g)", calories=143, protein_g=12.6, carbs_g=0.8, fats_g=9.5),
            FoodItem(name="Egg Whites", category="Protein", cuisine="Global", is_vegetarian=False, serving_size="100g", calories=52, protein_g=11.0, carbs_g=0.7, fats_g=0.2),
            FoodItem(name="Paneer (Low Fat)", category="Protein", cuisine="Indian", is_vegetarian=True, serving_size="100g", calories=180, protein_g=18.0, carbs_g=3.0, fats_g=10.0),
            FoodItem(name="Tofu (Firm)", category="Protein", cuisine="Global", is_vegetarian=True, serving_size="100g", calories=144, protein_g=17.0, carbs_g=3.0, fats_g=8.0),
            FoodItem(name="Soya Chunks", category="Protein", cuisine="Indian", is_vegetarian=True, serving_size="50g dry", calories=170, protein_g=26.0, carbs_g=16.0, fats_g=0.5),
            FoodItem(name="Whey Protein Powder", category="Protein", cuisine="Global", is_vegetarian=True, serving_size="1 scoop (30g)", calories=120, protein_g=24.0, carbs_g=2.0, fats_g=1.5),
            FoodItem(name="Fish (Salmon / Rohu)", category="Protein", cuisine="Global", is_vegetarian=False, serving_size="100g", calories=180, protein_g=22.0, carbs_g=0.0, fats_g=9.0),
            FoodItem(name="Greek Yogurt (Plain)", category="Protein", cuisine="Global", is_vegetarian=True, serving_size="150g", calories=100, protein_g=15.0, carbs_g=6.0, fats_g=0.5),

            # Carbohydrate Sources
            FoodItem(name="Brown Rice (Cooked)", category="Carbs", cuisine="Indian", is_vegetarian=True, serving_size="1 cup (150g)", calories=166, protein_g=3.5, carbs_g=36.0, fats_g=1.8),
            FoodItem(name="White Basmati Rice", category="Carbs", cuisine="Indian", is_vegetarian=True, serving_size="1 cup (150g)", calories=195, protein_g=4.0, carbs_g=43.0, fats_g=0.5),
            FoodItem(name="Whole Wheat Chapati / Roti", category="Carbs", cuisine="Indian", is_vegetarian=True, serving_size="1 medium roti (40g)", calories=104, protein_g=3.1, carbs_g=20.0, fats_g=1.2),
            FoodItem(name="Rolled Oats", category="Carbs", cuisine="Global", is_vegetarian=True, serving_size="50g dry", calories=190, protein_g=6.5, carbs_g=32.0, fats_g=3.5),
            FoodItem(name="Sweet Potato (Boiled)", category="Carbs", cuisine="Global", is_vegetarian=True, serving_size="1 medium (130g)", calories=112, protein_g=2.0, carbs_g=26.0, fats_g=0.1),
            FoodItem(name="Yellow Moong Dal (Cooked)", category="Carbs", cuisine="Indian", is_vegetarian=True, serving_size="1 bowl (150g)", calories=140, protein_g=8.5, carbs_g=22.0, fats_g=2.0),
            FoodItem(name="Roasted Chana", category="Snacks", cuisine="Indian", is_vegetarian=True, serving_size="50g", calories=185, protein_g=9.5, carbs_g=28.0, fats_g=3.0),
            FoodItem(name="Banana", category="Fruits", cuisine="Global", is_vegetarian=True, serving_size="1 medium (118g)", calories=105, protein_g=1.3, carbs_g=27.0, fats_g=0.3),
            FoodItem(name="Apple", category="Fruits", cuisine="Global", is_vegetarian=True, serving_size="1 medium (150g)", calories=95, protein_g=0.5, carbs_g=25.0, fats_g=0.3),

            # Healthy Fats & Nuts
            FoodItem(name="Almonds", category="Fats", cuisine="Global", is_vegetarian=True, serving_size="10 nuts (12g)", calories=70, protein_g=2.5, carbs_g=2.5, fats_g=6.0),
            FoodItem(name="Walnuts", category="Fats", cuisine="Global", is_vegetarian=True, serving_size="5 halves (15g)", calories=98, protein_g=2.3, carbs_g=2.0, fats_g=9.8),
            FoodItem(name="Peanut Butter", category="Fats", cuisine="Global", is_vegetarian=True, serving_size="1 tbsp (16g)", calories=94, protein_g=4.0, carbs_g=3.0, fats_g=8.0)
        ]
        db.add_all(foods)

    db.commit()
    db.close()
    print("Database successfully seeded with users, exercises, and nutrition data!")

if __name__ == "__main__":
    seed_database()
