@echo off
echo ===================================================
echo   Starting FitTrack AI Platform (Backend & Frontend)
echo ===================================================
echo.

echo [1/3] Training Machine Learning Recommendation Model...
python ml/train_model.py

echo.
echo [2/3] Starting FastAPI Backend Server on http://localhost:8000...
start cmd /k "cd backend && uvicorn app.main:app --reload --port 8000"

echo.
echo [3/3] Starting React Vite Frontend on http://localhost:3000...
start cmd /k "cd frontend && npm run dev"

echo.
echo FitTrack AI launch commands initiated!
echo Access Web App: http://localhost:3000
echo Access API Docs: http://localhost:8000/docs
pause
