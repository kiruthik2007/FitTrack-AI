from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime

from app.database.connection import get_db
from app.models.schema import (
    User, UserProfile, WorkoutPlan, Exercise, WorkoutLog,
    FoodItem, MealLog, ProgressLog, Achievement
)
from app.schemas.pydantic_models import (
    UserProfileCreate, UserProfileResponse, CalculatorRequest, CalculatorResponse,
    WorkoutLogCreate, WorkoutLogResponse, MealLogCreate, MealLogResponse,
    ProgressLogCreate, ProgressLogResponse, FoodItemResponse, ExerciseResponse
)
from app.auth.security import get_current_user
from app.services.fitness_engine import (
    calculate_fitness_metrics, generate_personalized_workout_plan, generate_personalized_diet_plan
)

router = APIRouter(prefix="/api/fitness", tags=["Fitness Platform"])

# 1. Standalone Fitness Calculator Endpoint
@router.post("/calculate", response_model=CalculatorResponse)
def calculate_metrics(req: CalculatorRequest):
    metrics = calculate_fitness_metrics(
        age=req.age,
        gender=req.gender,
        height_cm=req.height_cm,
        weight_kg=req.weight_kg,
        activity_level=req.activity_level,
        goal=req.goal
    )
    return metrics


# 2. User Onboarding & Profile Setup
@router.post("/onboarding", response_model=UserProfileResponse)
def complete_onboarding(
    profile_data: UserProfileCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Calculate fitness metrics
    metrics = calculate_fitness_metrics(
        age=profile_data.age,
        gender=profile_data.gender,
        height_cm=profile_data.height_cm,
        weight_kg=profile_data.weight_kg,
        activity_level=profile_data.activity_level,
        goal=profile_data.fitness_goal
    )

    existing_profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    
    if existing_profile:
        # Update existing profile
        for key, value in profile_data.model_dump().items():
            setattr(existing_profile, key, value)
        existing_profile.bmi = metrics["bmi"]
        existing_profile.bmr = metrics["bmr"]
        existing_profile.tdee = metrics["tdee"]
        existing_profile.daily_calorie_target = metrics["target_calories"]
        existing_profile.protein_target_g = metrics["protein_g"]
        existing_profile.carbs_target_g = metrics["carbs_g"]
        existing_profile.fats_target_g = metrics["fats_g"]
        existing_profile.water_target_ml = metrics["water_ml"]
        profile_obj = existing_profile
    else:
        # Create new profile
        profile_obj = UserProfile(
            user_id=current_user.id,
            **profile_data.model_dump(),
            bmi=metrics["bmi"],
            bmr=metrics["bmr"],
            tdee=metrics["tdee"],
            daily_calorie_target=metrics["target_calories"],
            protein_target_g=metrics["protein_g"],
            carbs_target_g=metrics["carbs_g"],
            fats_target_g=metrics["fats_g"],
            water_target_ml=metrics["water_ml"]
        )
        db.add(profile_obj)

    # Generate Personalized Workout Plan
    workout_plan_data = generate_personalized_workout_plan(
        goal=profile_data.fitness_goal,
        fitness_level=profile_data.fitness_level,
        equipment=profile_data.equipment,
        days_per_week=profile_data.days_per_week
    )
    
    # Save/Update Workout Plan in DB
    existing_plan = db.query(WorkoutPlan).filter(WorkoutPlan.user_id == current_user.id).first()
    if existing_plan:
        existing_plan.plan_name = workout_plan_data["plan_name"]
        existing_plan.split_type = workout_plan_data["split_type"]
        existing_plan.weekly_schedule = workout_plan_data["weekly_schedule"]
    else:
        new_plan = WorkoutPlan(
            user_id=current_user.id,
            plan_name=workout_plan_data["plan_name"],
            split_type=workout_plan_data["split_type"],
            weekly_schedule=workout_plan_data["weekly_schedule"]
        )
        db.add(new_plan)

    db.commit()
    db.refresh(profile_obj)
    return profile_obj


# 3. Get User Profile
@router.get("/profile", response_model=UserProfileResponse)
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="User profile not completed yet.")
    return profile


# 4. Get User Workout Plan
@router.get("/workout-plan")
def get_workout_plan(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    plan = db.query(WorkoutPlan).filter(WorkoutPlan.user_id == current_user.id).first()
    if not plan:
        # Generate default plan if profile exists
        profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
        if profile:
            plan_data = generate_personalized_workout_plan(
                profile.fitness_goal, profile.fitness_level, profile.equipment, profile.days_per_week
            )
            return plan_data
        raise HTTPException(status_code=404, detail="No workout plan found. Please complete onboarding.")
    return plan


# 5. Get User Diet Plan
@router.get("/diet-plan")
def get_diet_plan(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=404, detail="No profile found. Please complete onboarding.")
    
    diet_plan = generate_personalized_diet_plan(
        target_calories=profile.daily_calorie_target or 2000,
        protein_g=profile.protein_target_g or 120,
        carbs_g=profile.carbs_target_g or 200,
        fats_g=profile.fats_target_g or 55,
        dietary_preference=profile.dietary_preference or "non_vegetarian"
    )
    return diet_plan


# 6. Workout Logs
@router.post("/workout-logs", response_model=WorkoutLogResponse)
def log_workout(
    log_data: WorkoutLogCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    log = WorkoutLog(user_id=current_user.id, **log_data.model_dump())
    db.add(log)
    db.commit()
    db.refresh(log)
    return log

@router.get("/workout-logs", response_model=List[WorkoutLogResponse])
def get_workout_logs(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    logs = db.query(WorkoutLog).filter(WorkoutLog.user_id == current_user.id).order_by(WorkoutLog.id.desc()).all()
    return logs


# 7. Meal & Nutrition Logs
@router.post("/meal-logs", response_model=MealLogResponse)
def log_meal(
    meal_data: MealLogCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    log = MealLog(user_id=current_user.id, **meal_data.model_dump())
    db.add(log)
    db.commit()
    db.refresh(log)
    return log

@router.get("/meal-logs", response_model=List[MealLogResponse])
def get_meal_logs(
    date: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(MealLog).filter(MealLog.user_id == current_user.id)
    if date:
        query = query.filter(MealLog.date == date)
    return query.order_by(MealLog.id.desc()).all()


# 8. Progress Logs
@router.post("/progress-logs", response_model=ProgressLogResponse)
def log_progress(
    progress_data: ProgressLogCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    log = ProgressLog(user_id=current_user.id, **progress_data.model_dump())
    db.add(log)
    
    # Update current weight in profile as well
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if profile:
        profile.weight_kg = progress_data.weight_kg
        # Recalculate BMI
        height_m = profile.height_cm / 100.0
        profile.bmi = round(progress_data.weight_kg / (height_m ** 2), 1)

    db.commit()
    db.refresh(log)
    return log

@router.get("/progress-logs", response_model=List[ProgressLogResponse])
def get_progress_logs(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(ProgressLog).filter(ProgressLog.user_id == current_user.id).order_by(ProgressLog.id.asc()).all()


# 9. Search Exercises & Foods
@router.get("/exercises", response_model=List[ExerciseResponse])
def get_exercises(
    category: Optional[str] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(Exercise)
    if category:
        query = query.filter(Exercise.category.ilike(f"%{category}%"))
    if search:
        query = query.filter(Exercise.name.ilike(f"%{search}%"))
    return query.limit(50).all()

@router.get("/foods", response_model=List[FoodItemResponse])
def get_foods(
    search: Optional[str] = None,
    category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(FoodItem)
    if category:
        query = query.filter(FoodItem.category.ilike(f"%{category}%"))
    if search:
        query = query.filter(FoodItem.name.ilike(f"%{search}%"))
    return query.limit(50).all()


# 10. Central Dashboard Summary Endpoint
@router.get("/dashboard-summary")
def get_dashboard_summary(
    date: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    today_str = date or datetime.utcnow().strftime("%Y-%m-%d")
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    
    # Get today's meal logs
    meals = db.query(MealLog).filter(MealLog.user_id == current_user.id, MealLog.date == today_str).all()
    consumed_calories = sum(m.calories for m in meals)
    consumed_protein = sum(m.protein_g for m in meals)
    consumed_carbs = sum(m.carbs_g for m in meals)
    consumed_fats = sum(m.fats_g for m in meals)

    # Get today's workout logs
    workouts = db.query(WorkoutLog).filter(WorkoutLog.user_id == current_user.id, WorkoutLog.date == today_str).all()
    calories_burned = sum(w.calories_burned for w in workouts)

    target_cal = profile.daily_calorie_target if profile else 2200
    target_protein = profile.protein_target_g if profile else 130
    target_carbs = profile.carbs_target_g if profile else 220
    target_fats = profile.fats_target_g if profile else 60

    return {
        "user_name": current_user.full_name,
        "streak_count": profile.streak_count if profile else 1,
        "points": profile.points if profile else 100,
        "current_weight": profile.weight_kg if profile else 70.0,
        "target_weight": profile.target_weight_kg if profile else 65.0,
        "bmi": profile.bmi if profile else 22.5,
        "calories": {
            "target": target_cal,
            "consumed": consumed_calories,
            "burned": calories_burned,
            "remaining": max(0, target_cal - consumed_calories + calories_burned)
        },
        "macros": {
            "protein": {"target": target_protein, "consumed": consumed_protein},
            "carbs": {"target": target_carbs, "consumed": consumed_carbs},
            "fats": {"target": target_fats, "consumed": consumed_fats}
        },
        "water_target_ml": profile.water_target_ml if profile else 3000,
        "todays_workouts": len(workouts),
        "todays_meals": len(meals)
    }
