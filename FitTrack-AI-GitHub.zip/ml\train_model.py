import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score
import joblib
import os

def generate_synthetic_fitness_data(num_samples=1200):
    np.random.seed(42)
    ages = np.random.randint(18, 65, size=num_samples)
    genders = np.random.choice([0, 1], size=num_samples) # 0: Female, 1: Male
    heights = np.random.normal(172, 10, size=num_samples).clip(150, 200)
    weights = np.random.normal(74, 14, size=num_samples).clip(45, 120)
    days_per_week = np.random.randint(3, 7, size=num_samples)
    duration_mins = np.random.choice([30, 45, 60, 75, 90], size=num_samples)

    # Compute exact physics/biology based metrics
    bmis = weights / ((heights / 100.0) ** 2)
    bmrs = (10 * weights) + (6.25 * heights) - (5 * ages) + (5 * genders - 161 * (1 - genders))
    tdees = bmrs * (1.2 + (days_per_week * 0.1))

    # Add realistic goal variations (-300 deficit for weight loss, +300 surplus for gain)
    goal_offsets = np.random.choice([-400, 0, 350], size=num_samples)
    target_calories = tdees + goal_offsets + np.random.normal(0, 30, size=num_samples)
    target_protein = (weights * (1.6 + (genders * 0.4))) + np.random.normal(0, 5, size=num_samples)

    df = pd.DataFrame({
        "age": ages,
        "height_cm": np.round(heights, 1),
        "weight_kg": np.round(weights, 1),
        "bmi": np.round(bmis, 1),
        "days_per_week": days_per_week,
        "duration_mins": duration_mins,
        "target_calories": np.round(target_calories, 0),
        "target_protein_g": np.round(target_protein, 0)
    })
    return df

def train_and_save_ml_model():
    print("Generating synthetic fitness dataset (1,200 samples)...")
    df = generate_synthetic_fitness_data(1200)

    X = df[["age", "height_cm", "weight_kg", "bmi", "days_per_week", "duration_mins"]]
    y = df[["target_calories", "target_protein_g"]]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    print(f"Model Training Complete!")
    print(f"Mean Absolute Error (MAE): {mae:.2f}")
    print(f"R^2 Score: {r2:.4f}")

    save_dir = os.path.join(os.path.dirname(__file__), "saved_models")
    os.makedirs(save_dir, exist_ok=True)
    model_filepath = os.path.join(save_dir, "fitness_recommendation_model.pkl")

    joblib.dump(model, model_filepath)
    print(f"Saved trained Machine Learning model to: {model_filepath}")

if __name__ == "__main__":
    train_and_save_ml_model()
