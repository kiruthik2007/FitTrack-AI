import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to attach JWT token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('fittrack_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
}, (error) => Promise.reject(error));

export const authAPI = {
  register: (data: any) => api.post('/auth/register', data),
  login: (data: any) => api.post('/auth/login', data),
  getMe: () => api.get('/auth/me'),
};

export const fitnessAPI = {
  calculate: (data: any) => api.post('/fitness/calculate', data),
  onboarding: (data: any) => api.post('/fitness/onboarding', data),
  getProfile: () => api.get('/fitness/profile'),
  getWorkoutPlan: () => api.get('/fitness/workout-plan'),
  getDietPlan: () => api.get('/fitness/diet-plan'),
  getDashboardSummary: () => api.get('/fitness/dashboard-summary'),
  logWorkout: (data: any) => api.post('/fitness/workout-logs', data),
  getWorkoutLogs: () => api.get('/fitness/workout-logs'),
  logMeal: (data: any) => api.post('/fitness/meal-logs', data),
  getMealLogs: (date?: string) => api.get('/fitness/meal-logs', { params: { date } }),
  logProgress: (data: any) => api.post('/fitness/progress-logs', data),
  getProgressLogs: () => api.get('/fitness/progress-logs'),
  getExercises: (category?: string, search?: string) => api.get('/fitness/exercises', { params: { category, search } }),
  getFoods: (search?: string, category?: string) => api.get('/fitness/foods', { params: { search, category } }),
};

export const aiAPI = {
  getRecommendation: () => api.post('/ai/recommendation'),
  chat: (message: string) => api.post('/ai/chat', { message }),
};
