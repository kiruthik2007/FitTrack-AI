from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database.connection import engine, Base
from app.routes import auth_routes, fitness_routes, ai_routes
from app.database.seed_data import seed_database

# Create DB tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="FitTrack AI Backend API",
    description="Intelligent Fitness, Workout, Nutrition & AI Recommendation Engine API",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Seed database on boot if empty
@app.on_event("startup")
def startup_event():
    try:
        seed_database()
    except Exception as e:
        print(f"Database seed note: {e}")

# Include Routers
app.include_router(auth_routes.router)
app.include_router(fitness_routes.router)
app.include_router(ai_routes.router)

@app.get("/")
def root():
    return {
        "status": "online",
        "message": "Welcome to FitTrack AI Platform REST API",
        "docs": "/docs"
    }

@app.get("/health")
def health_check():
    return {"status": "healthy"}
