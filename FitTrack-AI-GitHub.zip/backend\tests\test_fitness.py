import pytest
from app.services.fitness_engine import (
    calculate_fitness_metrics,
    generate_personalized_workout_plan,
    generate_personalized_diet_plan
)
from app.services.device_integration import FitnessDeviceService

def test_calculate_fitness_metrics_male():
    res = calculate_fitness_metrics(
        age=25,
        gender="male",
        height_cm=175.0,
        weight_kg=75.0,
        activity_level="moderate",
        goal="fat_loss"
    )
    assert res["bmi"] == 24.5
    assert res["bmi_category"] == "Normal weight"
    assert res["bmr"] > 1600
    assert res["tdee"] > 2400
    assert res["target_calories"] < res["tdee"]
    assert res["protein_g"] == 150
    assert res["water_ml"] > 3000

def test_calculate_fitness_metrics_female_muscle_gain():
    res = calculate_fitness_metrics(
        age=30,
        gender="female",
        height_cm=165.0,
        weight_kg=60.0,
        activity_level="active",
        goal="muscle_gain"
    )
    assert res["target_calories"] > res["tdee"]
    assert res["protein_g"] == 120

def test_workout_plan_generation():
    plan = generate_personalized_workout_plan(
        goal="fat_loss",
        fitness_level="intermediate",
        equipment="full_gym",
        days_per_week=5
    )
    assert plan["split_type"] == "Push-Pull-Legs (5-Day Split)"
    assert len(plan["weekly_schedule"]) == 7

def test_diet_plan_generation():
    diet = generate_personalized_diet_plan(
        target_calories=2200,
        protein_g=150,
        carbs_g=220,
        fats_g=60,
        dietary_preference="vegetarian"
    )
    assert "Paneer" in diet["meals"]["lunch"]["name"] or "Tofu" in diet["meals"]["lunch"]["name"]
    assert diet["target_calories"] == 2200

def test_device_integration_service():
    service = FitnessDeviceService()
    providers = service.list_providers()
    assert len(providers) == 5
    
    apple_data = service.sync_provider("apple_health", user_id=1)
    assert apple_data["provider"] == "Apple Health"
    assert apple_data["data"]["steps"] >= 6500
