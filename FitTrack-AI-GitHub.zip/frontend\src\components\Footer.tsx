import React from 'react';
import { Dumbbell, Heart, Shield, Sparkles } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 transition-colors duration-200 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-brand-600 flex items-center justify-center text-white">
              <Dumbbell className="w-4 h-4" />
            </div>
            <span className="font-heading font-bold text-gray-900 dark:text-white">FITTRACK AI</span>
            <span className="text-xs text-gray-500 dark:text-gray-400">© 2026 FitTrack AI Platform. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-6 text-xs text-gray-500 dark:text-gray-400">
            <span className="flex items-center gap-1"><Sparkles className="w-3.5 h-3.5 text-amber-500" /> Powered by Machine Learning</span>
            <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5 text-blue-500" /> Safe Health Guardrails</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
