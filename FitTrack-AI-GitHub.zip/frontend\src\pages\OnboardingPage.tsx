import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Dumbbell, Utensils, Target, ArrowRight, ArrowLeft, Check, Sparkles } from 'lucide-react';
import { fitnessAPI } from '../services/api';

export const OnboardingPage: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    age: 25,
    gender: 'male',
    height_cm: 175,
    weight_kg: 75,
    target_weight_kg: 70,
    fitness_goal: 'fat_loss',
    fitness_level: 'beginner',
    workout_preference: 'gym',
    equipment: 'full_gym',
    days_per_week: 4,
    duration_mins: 45,
    dietary_preference: 'non_vegetarian',
    food_cuisine_preference: 'indian',
    activity_level: 'moderate',
    allergies: '',
    medical_conditions: ''
  });

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
  };

  const handlePrev = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = async () => {
    setLoading(true);
    setError('');
    try {
      await fitnessAPI.onboarding(formData);
      navigate('/dashboard');
    } catch (e: any) {
      setError(e.response?.data?.detail || 'Failed to save profile. Make sure you are logged in.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-12 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
      <div className="w-full max-w-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl shadow-xl p-6 sm:p-10">
        
        {/* Step Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-600 dark:text-brand-400">
              Step {step} of 4: {step === 1 ? 'Personal Profile' : step === 2 ? 'Goals & Level' : step === 3 ? 'Workout Setup' : 'Diet & Cuisine'}
            </span>
            <span className="text-xs text-gray-400 font-semibold">{step * 25}% Completed</span>
          </div>
          <div className="w-full h-2 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-brand-600 to-emerald-400 transition-all duration-300"
              style={{ width: `${step * 25}%` }}
            ></div>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 text-xs font-medium border border-red-200 dark:border-red-800">
            {error}
          </div>
        )}

        {/* STEP 1: Personal Parameters */}
        {step === 1 && (
          <div className="space-y-6 animate-in fade-in">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-gray-900 dark:text-white">Tell us about yourself</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">We use these exact parameters to calculate your BMR & TDEE.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Age (Years)</label>
                <input
                  type="number"
                  min="14"
                  max="90"
                  value={formData.age}
                  onChange={(e) => handleChange('age', parseInt(e.target.value) || 25)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Gender</label>
                <select
                  value={formData.gender}
                  onChange={(e) => handleChange('gender', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Height (cm)</label>
                <input
                  type="number"
                  min="120"
                  max="230"
                  value={formData.height_cm}
                  onChange={(e) => handleChange('height_cm', parseFloat(e.target.value) || 175)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Current Weight (kg)</label>
                <input
                  type="number"
                  min="30"
                  max="200"
                  value={formData.weight_kg}
                  onChange={(e) => handleChange('weight_kg', parseFloat(e.target.value) || 75)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Target Weight (kg)</label>
              <input
                type="number"
                min="30"
                max="200"
                value={formData.target_weight_kg}
                onChange={(e) => handleChange('target_weight_kg', parseFloat(e.target.value) || 70)}
                className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
              />
            </div>
          </div>
        )}

        {/* STEP 2: Fitness Goals & Level */}
        {step === 2 && (
          <div className="space-y-6 animate-in fade-in">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-gray-900 dark:text-white">What is your primary fitness goal?</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">This configures your calorie surplus/deficit and macro breakdown.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { id: 'weight_loss', label: 'Weight Loss', desc: 'Burn fat with calorie deficit' },
                { id: 'fat_loss', label: 'Fat Loss & Recomp', desc: 'Lose fat while maintaining muscle' },
                { id: 'muscle_gain', label: 'Muscle Gain (Bulk)', desc: 'Build mass with slight surplus' },
                { id: 'strength', label: 'Strength & Power', desc: 'Maximize bench/squat PRs' },
                { id: 'maintenance', label: 'General Maintenance', desc: 'Stay healthy & maintain weight' }
              ].map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleChange('fitness_goal', item.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    formData.fitness_goal === item.id
                      ? 'border-brand-500 bg-brand-50/50 dark:bg-brand-950/40 text-gray-900 dark:text-white shadow-sm'
                      : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <div className="font-bold text-sm">{item.label}</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{item.desc}</div>
                </div>
              ))}
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-2">Fitness Experience Level</label>
              <div className="grid grid-cols-3 gap-3">
                {['beginner', 'intermediate', 'advanced'].map((lvl) => (
                  <button
                    type="button"
                    key={lvl}
                    onClick={() => handleChange('fitness_level', lvl)}
                    className={`py-2.5 rounded-xl border text-xs font-semibold uppercase tracking-wider transition-all ${
                      formData.fitness_level === lvl
                        ? 'border-brand-500 bg-brand-600 text-white'
                        : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Workout Preferences */}
        {step === 3 && (
          <div className="space-y-6 animate-in fade-in">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-gray-900 dark:text-white">Workout Preferences</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Tell us where you train and how much time you have.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Workout Location</label>
                <select
                  value={formData.workout_preference}
                  onChange={(e) => handleChange('workout_preference', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                >
                  <option value="gym">Gym Workout</option>
                  <option value="home">Home Workout</option>
                  <option value="outdoor">Outdoor / Park</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Available Equipment</label>
                <select
                  value={formData.equipment}
                  onChange={(e) => handleChange('equipment', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                >
                  <option value="full_gym">Full Gym Machines & Barbells</option>
                  <option value="dumbbells">Dumbbells & Bench</option>
                  <option value="resistance_bands">Resistance Bands</option>
                  <option value="no_equipment">Bodyweight / No Equipment</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Days Per Week ({formData.days_per_week} days)</label>
                <input
                  type="range"
                  min="3"
                  max="6"
                  value={formData.days_per_week}
                  onChange={(e) => handleChange('days_per_week', parseInt(e.target.value))}
                  className="w-full accent-brand-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Session Duration ({formData.duration_mins} mins)</label>
                <select
                  value={formData.duration_mins}
                  onChange={(e) => handleChange('duration_mins', parseInt(e.target.value))}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                >
                  <option value="30">30 minutes (Express)</option>
                  <option value="45">45 minutes (Standard)</option>
                  <option value="60">60 minutes (Intense)</option>
                  <option value="75">75+ minutes (Extended)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: Dietary Preferences */}
        {step === 4 && (
          <div className="space-y-6 animate-in fade-in">
            <div>
              <h2 className="font-heading font-extrabold text-2xl text-gray-900 dark:text-white">Nutrition & Dietary Choices</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Customizes your meal suggestions (Paneer/Soya for Veg, Eggs/Chicken for Non-Veg).</p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                { id: 'vegetarian', label: 'Vegetarian', icon: '🥦' },
                { id: 'non_vegetarian', label: 'Non-Vegetarian', icon: '🍗' },
                { id: 'vegan', label: 'Vegan', icon: '🌱' },
                { id: 'eggetarian', label: 'Eggetarian', icon: '🥚' }
              ].map((diet) => (
                <div
                  key={diet.id}
                  onClick={() => handleChange('dietary_preference', diet.id)}
                  className={`p-4 rounded-2xl border cursor-pointer flex items-center gap-3 transition-all ${
                    formData.dietary_preference === diet.id
                      ? 'border-brand-500 bg-brand-50/50 dark:bg-brand-950/40 text-gray-900 dark:text-white shadow-sm'
                      : 'border-gray-200 dark:border-gray-800 hover:border-gray-300 dark:hover:border-gray-700'
                  }`}
                >
                  <span className="text-2xl">{diet.icon}</span>
                  <span className="font-bold text-sm">{diet.label}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Cuisine Preference</label>
                <select
                  value={formData.food_cuisine_preference}
                  onChange={(e) => handleChange('food_cuisine_preference', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                >
                  <option value="indian">Indian Foods & Dishes</option>
                  <option value="western">Western / Global Cuisine</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">Daily Activity Level</label>
                <select
                  value={formData.activity_level}
                  onChange={(e) => handleChange('activity_level', e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-900 dark:text-white outline-none"
                >
                  <option value="sedentary">Sedentary (Desk Job)</option>
                  <option value="light">Lightly Active</option>
                  <option value="moderate">Moderately Active</option>
                  <option value="active">Very Active</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="mt-8 flex items-center justify-between pt-4 border-t border-gray-100 dark:border-gray-800">
          {step > 1 ? (
            <button
              type="button"
              onClick={handlePrev}
              className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold text-sm hover:bg-gray-100 dark:hover:bg-gray-800 flex items-center gap-1.5"
            >
              <ArrowLeft className="w-4 h-4" /> Previous
            </button>
          ) : (
            <div></div>
          )}

          {step < 4 ? (
            <button
              type="button"
              onClick={handleNext}
              className="px-6 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold text-sm flex items-center gap-1.5 shadow-md shadow-brand-600/20"
            >
              Next Step <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={loading}
              className="px-8 py-3 rounded-xl bg-gradient-to-r from-brand-600 to-emerald-500 hover:from-brand-700 hover:to-emerald-600 text-white font-bold text-sm flex items-center gap-2 shadow-xl shadow-brand-600/30"
            >
              {loading ? 'Generating Plan...' : 'Generate My FitTrack Plan'}
              <Sparkles className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
