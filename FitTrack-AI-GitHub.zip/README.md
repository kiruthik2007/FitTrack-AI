# FitTrack AI — Intelligent Fitness, Nutrition & Health Platform

[![React](https://img.shields.io/badge/React-18-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.100+-009688?logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.3-38B2AC?logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Docker](https://img.shields.io/badge/Docker-Ready-2496ED?logo=docker&logoColor=white)](https://www.docker.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

FitTrack AI is a commercial-grade, full-stack fitness and nutrition intelligence platform that dynamically calculates, tracks, and optimizes workout routines, dietary macros, calorie targets, and body metrics.

Built as both a **zero-install standalone web application** (ready for instant GitHub Pages hosting via `index.html`) and an **enterprise full-stack microservices architecture** (FastAPI backend + React/TypeScript Vite frontend + Scikit-Learn ML engine).

---

## 🌟 Key Features

### 1. 📊 10 Scientific Body & Health Calculators (with PDF Export)
- **Body Mass Index (BMI)**: WHO categorized with color-coded classification.
- **Basal Metabolic Rate (BMR)**: Mifflin-St Jeor equation.
- **Total Daily Energy Expenditure (TDEE)**: 5-level Katch-McArdle / Harris-Benedict multipliers.
- **Calorie Targets & Deficit/Surplus**: Tailored to Fat Loss, Muscle Gain, or Maintenance.
- **Target Macro Breakdown**: Body-weight anchored protein and fat ratios with auto-filling carbs.
- **Optimal Hydration**: 35ml/kg baseline plus workout activity adjustment.
- **Body Fat % (U.S. Navy Method)**: Circumference-based composition estimation.
- **Ideal Body Weight**: Multi-formula comparison (Hamwi, Devine, Robinson, Miller).
- **Maximum Muscular Potential**: Casey Butt lean mass ceiling algorithm.
- **One Rep Max (1RM)**: Epley / Brzycki strength benchmarks.
- **Export to PDF**: One-click professional report generation powered by jsPDF & html2canvas.

### 2. 🥗 Smart Nutrition & Meal Logging with Auto-Classification
- **Macro Source Auto-Classifier**: Automatically identifies whether an added meal is primarily a **Protein Source**, **Carb Source**, or **Healthy Fat Source** based on caloric nutrient density.
- **AI-Powered Calorie Estimator**: Built-in Gemini flash intelligence to estimate nutrition from natural language meal descriptions.
- **Dynamic Calorie & Macro Rings**: Visual SVG progress rings tracking remaining calories, eaten calories, and burned calories.
- **Custom Food Database**: Rich database featuring Indian dishes and global items with instant filtering.

### 3. 🏋️ 10 Legendary Workout Splits & Exercise Tracker
- Curated workout routines inspired by legends and modern exercise science:
  - **The Classic** (Steve Reeves Full Body)
  - **The Beast** (Ronnie Coleman Push Pull Legs)
  - **The Legend** (Arnold Schwarzenegger Golden Era Split)
  - **The Scientist** (Jeff Nippard Evidence-Based Hypertrophy)
  - **The Mountain Dog** (John Meadows High Intensity)
  - **The Hybrid** (Layne Norton PHAT / PHUL)
  - **The Machine** (Jay Cutler Bro Split)
- Live rest timers, set/rep/weight tracking, and Personal Record (PR) notifications.

### 4. 👤 Dynamic Profile & Custom Macro Customization
- Instant TDEE & macro recalculation on age, height, weight, goal, or activity adjustments.
- Custom Calorie Override modal allowing direct targets with live macro readjustments.
- LocalStorage persistence with resilient state management and React Error Boundaries.

### 5. 🤖 FitCoach AI Assistant
- Context-aware fitness advisor analyzing user metrics to provide structured guidance with health guardrails.

---

## 🚀 Quick Start Options

### Option 1: Instant Web App (No Installation Needed)
Simply double-click or open `index.html` (or `app.html`) in any modern web browser.
- Zero dependencies required.
- **Ready for GitHub Pages**: Push this repository to GitHub, go to **Settings > Pages**, select the `main` branch, and your live site is instantly deployed!

### Option 2: Docker Compose (Full Stack)
```bash
docker-compose up --build -d
```
- **Frontend**: `http://localhost:3000`
- **Backend API**: `http://localhost:8000`
- **Interactive API Docs**: `http://localhost:8000/docs`
- **PostgreSQL**: `localhost:5432`

### Option 3: Local Developer Setup

#### 1. Backend (FastAPI)
```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate

pip install -r requirements.txt
python -m app.database.seed_data
uvicorn app.main:app --reload --port 8000
```

#### 2. Frontend (React + Vite + TypeScript)
```bash
cd frontend
npm install
npm run dev
```

#### 3. Machine Learning Service
```bash
python ml/train_model.py
```

---

## 📁 Repository Structure

```
fittrack-ai/
├── index.html            # Standalone SPA (GitHub Pages ready)
├── app.html              # Standalone web app runner
├── README.md             # Project documentation
├── .gitignore            # Git exclusion rules
├── .env.example          # Environment variables template
├── docker-compose.yml    # Container orchestration
├── start_project.bat     # Windows 1-click startup
├── serve.ps1             # PowerShell static server
├── backend/              # FastAPI Python backend
│   ├── app/
│   │   ├── api/          # REST route handlers
│   │   ├── core/         # Config and security
│   │   ├── database/     # Models and migrations
│   │   └── services/     # Business logic & wearables
│   ├── tests/            # Pytest test suite
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/             # React 18 TypeScript application
│   ├── src/
│   │   ├── components/   # UI components
│   │   ├── context/      # State management
│   │   └── pages/        # Views
│   ├── package.json
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   ├── vite.config.ts
│   └── Dockerfile
└── ml/                   # Machine Learning algorithms
    ├── saved_models/     # Model weights
    └── train_model.py    # Random Forest training script
```

---

## 📤 Posting to GitHub

1. Create a new repository on [GitHub](https://github.com/new) (e.g., `fittrack-ai`).
2. In your local project folder, run:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: FitTrack AI complete platform"
   git branch -M main
   git remote add origin https://github.com/<your-username>/fittrack-ai.git
   git push -u origin main
   ```
3. **Enable GitHub Pages (Free Live Website)**:
   - Go to your repository **Settings** > **Pages**.
   - Under **Build and deployment** > **Source**, choose **Deploy from a branch**.
   - Select branch **`main`** and folder **`/ (root)`**, then click **Save**.
   - In 1–2 minutes, your website will be live at `https://<your-username>.github.io/fittrack-ai/`!

---

## 📄 License
This project is licensed under the MIT License - see the LICENSE file for details.
