import React, { useState, useEffect } from 'react';
import { Utensils, Search, Plus, CheckCircle, Leaf, Flame, Shield, Filter } from 'lucide-react';
import { fitnessAPI } from '../services/api';
import { FoodItem, DietPlan } from '../types';

export const DietPage: React.FC = () => {
  const [dietPlan, setDietPlan] = useState<DietPlan | null>(null);
  const [foods, setFoods] = useState<FoodItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [loggedMeals, setLoggedMeals] = useState<any[]>([]);

  // Log Meal Modal State
  const [logModalOpen, setLogModalOpen] = useState(false);
  const [selectedFood, setSelectedFood] = useState<FoodItem | null>(null);
  const [mealType, setMealType] = useState('Breakfast');
  const [servings, setServings] = useState(1.0);

  const fetchDietData = async () => {
    try {
      const dietRes = await fitnessAPI.getDietPlan();
      setDietPlan(dietRes.data);

      const foodRes = await fitnessAPI.getFoods();
      setFoods(foodRes.data);

      const mealLogRes = await fitnessAPI.getMealLogs();
      setLoggedMeals(mealLogRes.data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchDietData();
  }, []);

  const handleLogMealSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFood) return;

    try {
      await fitnessAPI.logMeal({
        date: new Date().toISOString().split('T')[0],
        meal_type: mealType,
        food_name: selectedFood.name,
        serving_quantity: servings,
        calories: selectedFood.calories * servings,
        protein_g: selectedFood.protein_g * servings,
        carbs_g: selectedFood.carbs_g * servings,
        fats_g: selectedFood.fats_g * servings
      });
      setLogModalOpen(false);
      fetchDietData();
      alert(`Successfully logged ${selectedFood.name} to ${mealType}!`);
    } catch (err) {
      console.error(err);
    }
  };

  const filteredFoods = foods.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || item.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = selectedCategory === 'All' || item.category.toLowerCase() === selectedCategory.toLowerCase();
    return matchesSearch && matchesCat;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <Utensils className="w-4 h-4" /> Nutrition & Meal Planner
            </div>
            <h1 className="font-heading font-extrabold text-3xl">Diet & Calorie Tracker</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Search Indian & global foods, track your daily protein/carb macros, and follow your plan.
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <div className="px-4 py-2.5 rounded-2xl bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 text-brand-700 dark:text-brand-300">
              Target: {dietPlan?.target_calories || 2200} kcal/day
            </div>
            <div className="px-4 py-2.5 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800/60 text-blue-700 dark:text-blue-300">
              Protein: {dietPlan?.protein_g || 140}g/day
            </div>
          </div>
        </div>

        {/* Meal Categories Grid (Breakfast, Lunch, Snacks, Dinner) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { key: 'breakfast', title: 'Breakfast', icon: '🥣', plan: dietPlan?.meals?.breakfast },
            { key: 'lunch', title: 'Lunch', icon: '🥗', plan: dietPlan?.meals?.lunch },
            { key: 'snacks', title: 'Evening Snacks', icon: '🍎', plan: dietPlan?.meals?.snacks },
            { key: 'dinner', title: 'Dinner', icon: '🍲', plan: dietPlan?.meals?.dinner }
          ].map((meal) => (
            <div
              key={meal.key}
              className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">{meal.icon}</span>
                  <span className="text-xs font-bold text-brand-600 bg-brand-50 dark:bg-brand-950 px-2.5 py-1 rounded-full">
                    ~{meal.plan?.calories || 450} kcal
                  </span>
                </div>
                <h3 className="font-heading font-bold text-lg mb-1">{meal.title}</h3>
                <p className="text-xs text-gray-600 dark:text-gray-300 font-medium mb-3">{meal.plan?.name || 'Recommended Meal'}</p>

                <div className="space-y-1 text-xs text-gray-500">
                  <div className="flex justify-between">
                    <span>Protein:</span>
                    <span className="font-semibold text-gray-700 dark:text-gray-200">{meal.plan?.protein_g || 30}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Carbs:</span>
                    <span className="font-semibold text-gray-700 dark:text-gray-200">{meal.plan?.carbs_g || 45}g</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  setMealType(meal.title);
                  if (foods.length > 0) setSelectedFood(foods[0]);
                  setLogModalOpen(true);
                }}
                className="mt-4 w-full py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 hover:bg-brand-600 hover:text-white text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors flex items-center justify-center gap-1"
              >
                <Plus className="w-4 h-4" /> Add Food Item
              </button>
            </div>
          ))}
        </div>

        {/* Searchable Food Database */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 sm:p-8 space-y-6 shadow-sm">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <h2 className="font-heading font-extrabold text-xl">Search Food Database</h2>
            
            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto scrollbar-none">
              {['All', 'Protein', 'Carbs', 'Fats', 'Fruits', 'Snacks'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    selectedCategory === cat
                      ? 'bg-brand-600 text-white'
                      : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Indian or global dishes (Paneer, Chicken Breast, Eggs, Rice, Oats, Dal)..."
              className="w-full pl-10 pr-4 py-3 rounded-2xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-sm outline-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredFoods.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/40 border border-gray-200/80 dark:border-gray-700/60 card-shine flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-gray-900 dark:text-white">{item.name}</span>
                    {item.is_vegetarian ? (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-700 font-semibold">VEG</span>
                    ) : (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-100 text-red-700 font-semibold">NON-VEG</span>
                    )}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Serving: {item.serving_size} | <span className="text-brand-600 dark:text-brand-400 font-bold">{item.calories} kcal</span>
                  </div>
                  <div className="text-[11px] text-gray-400 mt-0.5">
                    P: {item.protein_g}g | C: {item.carbs_g}g | F: {item.fats_g}g
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedFood(item);
                    setLogModalOpen(true);
                  }}
                  className="p-2 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-sm transition-colors"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* LOG MEAL MODAL */}
        {logModalOpen && selectedFood && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="w-full max-w-md bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-6 space-y-4 shadow-2xl">
              <h3 className="font-heading font-bold text-xl">Log {selectedFood.name}</h3>
              <form onSubmit={handleLogMealSubmit} className="space-y-4 text-sm">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Meal Category</label>
                  <select
                    value={mealType}
                    onChange={(e) => setMealType(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  >
                    <option value="Breakfast">Breakfast</option>
                    <option value="Lunch">Lunch</option>
                    <option value="Snacks">Evening Snacks</option>
                    <option value="Dinner">Dinner</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                    Serving Quantity ({servings} × {selectedFood.serving_size})
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="10"
                    value={servings}
                    onChange={(e) => setServings(parseFloat(e.target.value) || 1.0)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>

                <div className="p-3 rounded-xl bg-gray-50 dark:bg-gray-800 text-xs space-y-1">
                  <div className="flex justify-between font-bold">
                    <span>Total Calories:</span>
                    <span className="text-brand-600">{Math.round(selectedFood.calories * servings)} kcal</span>
                  </div>
                  <div className="flex justify-between text-gray-500">
                    <span>Total Protein:</span>
                    <span>{Math.round(selectedFood.protein_g * servings)}g</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setLogModalOpen(false)}
                    className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-md"
                  >
                    Save Meal Log
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
