import React from 'react';
import { UserCheck, Users, Dumbbell, MessageSquare, Activity, CheckCircle } from 'lucide-react';

export const TrainerDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <UserCheck className="w-4 h-4" /> Gym Trainer Portal
            </div>
            <h1 className="font-heading font-extrabold text-3xl">Trainer Dashboard</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Monitor assigned clients, review workout consistency, and assign custom diet plans.
            </p>
          </div>
          <span className="px-3 py-1.5 rounded-xl bg-brand-100 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300 font-bold text-xs">
            TRAINER PORTAL
          </span>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 sm:p-8 space-y-4 shadow-sm">
          <h3 className="font-heading font-bold text-xl">Assigned Clients</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl bg-gray-50 dark:bg-gray-800/40 border border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <div>
                <div className="font-bold text-base">Alex Johnson</div>
                <div className="text-xs text-gray-500">Goal: Fat Loss (-4.0kg achieved)</div>
                <div className="text-xs text-brand-600 font-semibold mt-1">Streak: 7 Days 🔥</div>
              </div>
              <button className="px-3 py-1.5 rounded-xl bg-brand-600 text-white text-xs font-semibold">
                Assign Routine
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
