import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Flame, Award, Dumbbell, Utensils, Droplets, TrendingUp, Sparkles, Plus, CheckCircle, ArrowRight, Zap, RefreshCw } from 'lucide-react';
import { fitnessAPI, aiAPI } from '../services/api';
import { DashboardSummary } from '../types';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [waterLogged, setWaterLogged] = useState(1500); // Default demo water ml
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = async () => {
    try {
      const summaryRes = await fitnessAPI.getDashboardSummary();
      setSummary(summaryRes.data);

      const aiRes = await aiAPI.getRecommendation();
      setRecommendations(aiRes.data.recommendations || []);
    } catch (e) {
      console.error("Dashboard fetch error", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleAddWater = () => {
    setWaterLogged((prev) => prev + 250);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950 text-gray-500">
        <div className="flex items-center gap-2 font-medium">
          <RefreshCw className="w-5 h-5 animate-spin text-brand-600" /> Loading your personalized dashboard...
        </div>
      </div>
    );
  }

  const s = summary || {
    user_name: 'Alex',
    streak_count: 7,
    points: 350,
    current_weight: 78.0,
    target_weight: 72.0,
    bmi: 24.6,
    calories: { target: 2247, consumed: 1650, burned: 350, remaining: 947 },
    macros: {
      protein: { target: 156, consumed: 110 },
      carbs: { target: 220, consumed: 140 },
      fats: { target: 62, consumed: 45 }
    },
    water_target_ml: 3200,
    todays_workouts: 1,
    todays_meals: 3
  };

  const calConsumedPct = Math.min(100, Math.round((s.calories.consumed / s.calories.target) * 100));

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Welcome Header & Streaks */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-6 sm:p-8 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4" /> FitTrack AI Active Profile
            </div>
            <h1 className="font-heading font-extrabold text-3xl sm:text-4xl">
              Welcome back, {s.user_name}! 👋
            </h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Here is your daily fitness progress, calorie target breakdown, and AI recommendations.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="flex-1 md:flex-none flex items-center gap-3 px-4 py-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60">
              <Flame className="w-6 h-6 text-amber-500 fill-amber-500" />
              <div>
                <div className="font-extrabold text-lg leading-none text-amber-800 dark:text-amber-300">{s.streak_count} Days</div>
                <div className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold uppercase">Workout Streak</div>
              </div>
            </div>

            <div className="flex-1 md:flex-none flex items-center gap-3 px-4 py-3 rounded-2xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800/60">
              <Award className="w-6 h-6 text-purple-600 dark:text-purple-400" />
              <div>
                <div className="font-extrabold text-lg leading-none text-purple-800 dark:text-purple-300">{s.points} PTS</div>
                <div className="text-[10px] text-purple-600 dark:text-purple-400 font-semibold uppercase">Achieved Score</div>
              </div>
            </div>
          </div>
        </div>

        {/* AI Recommendations Banner */}
        {recommendations.length > 0 && (
          <div className="p-6 rounded-3xl bg-gradient-to-r from-brand-900/10 via-emerald-900/10 to-teal-900/10 border border-brand-500/30 dark:border-brand-500/20 backdrop-blur-sm space-y-3">
            <div className="flex items-center gap-2 font-heading font-bold text-base text-brand-700 dark:text-brand-300">
              <Sparkles className="w-5 h-5 text-amber-400 fill-amber-400" /> AI Recommendation Engine Insight
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.map((rec, i) => (
                <div key={i} className="p-4 rounded-2xl bg-white dark:bg-gray-900/80 border border-gray-200/80 dark:border-gray-800 text-sm">
                  <div className="font-bold text-gray-900 dark:text-white mb-1">{rec.title}</div>
                  <div className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">{rec.description}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Core Daily Overview Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Card 1: Calorie Summary & Ring */}
          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-bold text-lg">Calories Today</h3>
              <span className="text-xs font-bold text-brand-600 bg-brand-50 dark:bg-brand-950 px-2.5 py-1 rounded-full">
                Target: {s.calories.target} kcal
              </span>
            </div>

            <div className="flex flex-col items-center justify-center py-2">
              <div className="relative w-40 h-40 flex items-center justify-center">
                {/* SVG Radial Ring */}
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="80" cy="80" r="68" stroke="currentColor" strokeWidth="12" className="text-gray-100 dark:text-gray-800" fill="transparent" />
                  <circle
                    cx="80"
                    cy="80"
                    r="68"
                    stroke="currentColor"
                    strokeWidth="12"
                    strokeDasharray={427}
                    strokeDashoffset={427 - (427 * calConsumedPct) / 100}
                    strokeLinecap="round"
                    className="text-brand-500 transition-all duration-1000 ease-out"
                    fill="transparent"
                  />
                </svg>
                <div className="absolute flex flex-col items-center text-center">
                  <span className="font-heading font-extrabold text-3xl">{s.calories.remaining}</span>
                  <span className="text-[11px] font-semibold text-gray-400 uppercase tracking-wider">kcal remaining</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs pt-2 border-t border-gray-100 dark:border-gray-800">
              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                <span className="text-gray-500 dark:text-gray-400 block mb-0.5">Consumed</span>
                <span className="font-bold text-sm text-brand-600 dark:text-brand-400">{s.calories.consumed} kcal</span>
              </div>
              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/50">
                <span className="text-gray-500 dark:text-gray-400 block mb-0.5">Burned</span>
                <span className="font-bold text-sm text-amber-600 dark:text-amber-400">{s.calories.burned} kcal</span>
              </div>
            </div>
          </div>

          {/* Card 2: Macros Progress */}
          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="font-heading font-bold text-lg">Macros Breakdown</h3>
              <button
                onClick={() => navigate('/diet')}
                className="text-xs font-semibold text-brand-600 hover:underline flex items-center gap-1"
              >
                Log Meal <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Protein */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1.5">
                  <span className="text-gray-700 dark:text-gray-300">Protein</span>
                  <span>{s.macros.protein.consumed}g / {s.macros.protein.target}g</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
                  <div
                    className="h-full bg-brand-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (s.macros.protein.consumed / s.macros.protein.target) * 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Carbs */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1.5">
                  <span className="text-gray-700 dark:text-gray-300">Carbohydrates</span>
                  <span>{s.macros.carbs.consumed}g / {s.macros.carbs.target}g</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
                  <div
                    className="h-full bg-blue-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (s.macros.carbs.consumed / s.macros.carbs.target) * 100)}%` }}
                  ></div>
                </div>
              </div>

              {/* Fats */}
              <div>
                <div className="flex justify-between text-xs font-semibold mb-1.5">
                  <span className="text-gray-700 dark:text-gray-300">Fats</span>
                  <span>{s.macros.fats.consumed}g / {s.macros.fats.target}g</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-gray-100 dark:bg-gray-800 overflow-hidden">
                  <div
                    className="h-full bg-amber-500 rounded-full transition-all duration-500"
                    style={{ width: `${Math.min(100, (s.macros.fats.consumed / s.macros.fats.target) * 100)}%` }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Water Tracker Box */}
            <div className="pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-cyan-50 dark:bg-cyan-950/50 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
                  <Droplets className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-bold text-sm">{waterLogged} ml</div>
                  <div className="text-xs text-gray-500">Target: {s.water_target_ml} ml</div>
                </div>
              </div>
              <button
                onClick={handleAddWater}
                className="px-3 py-1.5 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 hover:bg-cyan-100 text-cyan-700 dark:text-cyan-300 text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> 250ml
              </button>
            </div>
          </div>

          {/* Card 3: Today's Workout Quick Launcher */}
          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-xl bg-brand-100 dark:bg-brand-900/40 text-brand-600 dark:text-brand-400 flex items-center justify-center">
                    <Dumbbell className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-heading font-bold text-lg">Today's Workout</h3>
                    <div className="text-xs text-gray-500">Push-Pull-Legs Split</div>
                  </div>
                </div>
                <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-1 rounded-full">
                  Day 1 Scheduled
                </span>
              </div>

              <div className="space-y-2.5 text-xs text-gray-600 dark:text-gray-300">
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/50 flex items-center justify-between">
                  <span className="font-semibold">Barbell Bench Press</span>
                  <span className="text-gray-500">4 sets × 8-10 reps</span>
                </div>
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/50 flex items-center justify-between">
                  <span className="font-semibold">Incline Dumbbell Press</span>
                  <span className="text-gray-500">3 sets × 10-12 reps</span>
                </div>
                <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/50 flex items-center justify-between">
                  <span className="font-semibold">Overhead Shoulder Press</span>
                  <span className="text-gray-500">3 sets × 10 reps</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => navigate('/workouts')}
              className="w-full py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm shadow-md shadow-brand-600/20 flex items-center justify-center gap-2 transition-all"
            >
              Start Workout Session
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Quick Links Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div
            onClick={() => navigate('/progress')}
            className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm cursor-pointer card-shine flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-base">Progress Charts</div>
              <div className="text-xs text-gray-500">View weight history & BMI graphs</div>
            </div>
          </div>

          <div
            onClick={() => navigate('/calculators')}
            className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm cursor-pointer card-shine flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-base">Fitness Calculators</div>
              <div className="text-xs text-gray-500">1RM, BMR, TDEE & Body Fat %</div>
            </div>
          </div>

          <div
            onClick={() => navigate('/diet')}
            className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm cursor-pointer card-shine flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Utensils className="w-6 h-6" />
            </div>
            <div>
              <div className="font-bold text-base">Nutrition Database</div>
              <div className="text-xs text-gray-500">Search Indian & global meal items</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
