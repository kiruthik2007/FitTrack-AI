from pydantic import BaseModel, EmailStr
from typing import Optional, List, Any, Dict
from datetime import datetime

# Token & Auth Schemas
class Token(BaseModel):
    access_token: str
    token_type: str
    user_id: int
    email: str
    full_name: str
    role: str

class TokenData(BaseModel):
    email: Optional[str] = None

class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    role: Optional[str] = "user"

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: str
    full_name: str
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

# Profile & Onboarding Schema
class UserProfileCreate(BaseModel):
    age: int
    gender: str # male, female, other
    height_cm: float
    weight_kg: float
    target_weight_kg: Optional[float] = None
    fitness_goal: str # weight_loss, muscle_gain, fat_loss, maintenance, strength
    fitness_level: str # beginner, intermediate, advanced
    workout_preference: str # gym, home, outdoor, hybrid
    equipment: str # no_equipment, dumbbells, resistance_bands, full_gym
    days_per_week: int = 4
    duration_mins: int = 45
    dietary_preference: str # vegetarian, non_vegetarian, vegan, eggetarian
    food_cuisine_preference: str = "indian"
    allergies: Optional[str] = None
    medical_conditions: Optional[str] = None
    activity_level: str = "moderate"

class UserProfileResponse(UserProfileCreate):
    id: int
    user_id: int
    bmi: Optional[float] = None
    bmr: Optional[float] = None
    tdee: Optional[float] = None
    daily_calorie_target: Optional[int] = None
    protein_target_g: Optional[int] = None
    carbs_target_g: Optional[int] = None
    fats_target_g: Optional[int] = None
    water_target_ml: Optional[int] = None
    streak_count: int = 1
    points: int = 100

    class Config:
        from_attributes = True

# Fitness Calculations
class CalculatorRequest(BaseModel):
    age: int
    gender: str
    height_cm: float
    weight_kg: float
    activity_level: str = "moderate"
    goal: str = "maintenance"

class CalculatorResponse(BaseModel):
    bmi: float
    bmi_category: str
    bmr: float
    tdee: float
    target_calories: int
    protein_g: int
    carbs_g: int
    fats_g: int
    water_ml: int

# Workout & Exercises Schemas
class ExerciseResponse(BaseModel):
    id: int
    name: str
    category: str
    muscle_group: str
    equipment: str
    difficulty: str
    instructions: Optional[str] = None
    video_url: Optional[str] = None

    class Config:
        from_attributes = True

class WorkoutLogCreate(BaseModel):
    date: str
    exercise_name: str
    category: str = "General"
    sets_completed: int = 3
    reps_completed: int = 10
    weight_kg: float = 0.0
    duration_mins: int = 30
    calories_burned: int = 150
    notes: Optional[str] = None

class WorkoutLogResponse(WorkoutLogCreate):
    id: int
    user_id: int

    class Config:
        from_attributes = True

# Food & Meal Schemas
class FoodItemResponse(BaseModel):
    id: int
    name: str
    category: str
    cuisine: str
    is_vegetarian: bool
    serving_size: str
    calories: float
    protein_g: float
    carbs_g: float
    fats_g: float

    class Config:
        from_attributes = True

class MealLogCreate(BaseModel):
    date: str
    meal_type: str
    food_name: str
    serving_quantity: float = 1.0
    calories: float
    protein_g: float
    carbs_g: float
    fats_g: float

class MealLogResponse(MealLogCreate):
    id: int
    user_id: int

    class Config:
        from_attributes = True

# Progress Schema
class ProgressLogCreate(BaseModel):
    date: str
    weight_kg: float
    body_fat_pct: Optional[float] = None
    chest_cm: Optional[float] = None
    waist_cm: Optional[float] = None
    arms_cm: Optional[float] = None
    thighs_cm: Optional[float] = None
    notes: Optional[str] = None

class ProgressLogResponse(ProgressLogCreate):
    id: int
    user_id: int

    class Config:
        from_attributes = True

# Chatbot Schema
class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    reply: str
    timestamp: datetime
