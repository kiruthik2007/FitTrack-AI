import React, { useState, useEffect } from 'react';
import { Dumbbell, Play, Pause, RotateCcw, Clock, Search, Filter, Plus, CheckCircle, Flame, Layers } from 'lucide-react';
import { fitnessAPI } from '../services/api';
import { Exercise, WorkoutPlan } from '../types';

export const WorkoutPage: React.FC = () => {
  const [workoutPlan, setWorkoutPlan] = useState<any>(null);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [selectedDay, setSelectedDay] = useState('Monday');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'schedule' | 'library'>('schedule');

  // Rest Timer State
  const [restTime, setRestTime] = useState(60);
  const [timerRunning, setTimerRunning] = useState(false);
  const [currentTimer, setCurrentTimer] = useState(60);

  // Log Workout Modal State
  const [logModalOpen, setLogModalOpen] = useState(false);
  const [selectedExName, setSelectedExName] = useState('');
  const [logSets, setLogSets] = useState(4);
  const [logReps, setLogReps] = useState(10);
  const [logWeight, setLogWeight] = useState(45.0);

  useEffect(() => {
    const loadData = async () => {
      try {
        const planRes = await fitnessAPI.getWorkoutPlan();
        setWorkoutPlan(planRes.data);

        const exRes = await fitnessAPI.getExercises();
        setExercises(exRes.data);
      } catch (e) {
        console.error(e);
      }
    };
    loadData();
  }, []);

  // Timer countdown hook
  useEffect(() => {
    let interval: any = null;
    if (timerRunning && currentTimer > 0) {
      interval = setInterval(() => {
        setCurrentTimer((prev) => prev - 1);
      }, 1000);
    } else if (currentTimer === 0) {
      setTimerRunning(false);
    }
    return () => clearInterval(interval);
  }, [timerRunning, currentTimer]);

  const handleStartRestTimer = (seconds: number) => {
    setRestTime(seconds);
    setCurrentTimer(seconds);
    setTimerRunning(true);
  };

  const handleLogExercise = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fitnessAPI.logWorkout({
        date: new Date().toISOString().split('T')[0],
        exercise_name: selectedExName,
        sets_completed: logSets,
        reps_completed: logReps,
        weight_kg: logWeight,
        duration_mins: 30,
        calories_burned: 180
      });
      setLogModalOpen(false);
      alert(`Logged ${selectedExName}: ${logSets} sets × ${logReps} reps @ ${logWeight}kg!`);
    } catch (err) {
      console.error(err);
    }
  };

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const currentDaySchedule = workoutPlan?.weekly_schedule?.find((d: any) => d.day === selectedDay) || {
    day: selectedDay,
    focus: 'Push (Chest & Shoulders)',
    exercises: [
      { name: 'Barbell Bench Press', sets: 4, reps: '8-10', rest: '90s' },
      { name: 'Incline Dumbbell Press', sets: 3, reps: '10-12', rest: '60s' },
      { name: 'Overhead Shoulder Press', sets: 3, reps: '10-12', rest: '60s' },
      { name: 'Lateral Raises', sets: 3, reps: '12-15', rest: '45s' },
      { name: 'Tricep Pushdowns', sets: 3, reps: '12-15', rest: '45s' }
    ]
  };

  const filteredExercises = exercises.filter((ex) => {
    const matchesCategory = selectedCategory === 'All' || ex.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = ex.name.toLowerCase().includes(searchQuery.toLowerCase()) || ex.muscle_group.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header & Tabs */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-gray-900 p-6 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <div>
            <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <Dumbbell className="w-4 h-4" /> Customized Workout Split
            </div>
            <h1 className="font-heading font-extrabold text-3xl">Workout & Exercise Module</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {workoutPlan?.plan_name || 'Push-Pull-Legs Hypertrophy Split'}
            </p>
          </div>

          <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-gray-100 dark:bg-gray-800">
            <button
              onClick={() => setActiveTab('schedule')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'schedule'
                  ? 'bg-white dark:bg-gray-900 text-brand-600 dark:text-brand-400 shadow-sm'
                  : 'text-gray-600 dark:text-gray-300'
              }`}
            >
              Weekly Schedule
            </button>
            <button
              onClick={() => setActiveTab('library')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'library'
                  ? 'bg-white dark:bg-gray-900 text-brand-600 dark:text-brand-400 shadow-sm'
                  : 'text-gray-600 dark:text-gray-300'
              }`}
            >
              Exercise Library
            </button>
          </div>
        </div>

        {/* Rest Timer Banner */}
        <div className="p-6 rounded-3xl bg-gradient-to-r from-gray-900 to-gray-800 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-brand-500/20 text-brand-400 flex items-center justify-center font-heading font-extrabold text-2xl border border-brand-500/30">
              {currentTimer}s
            </div>
            <div>
              <div className="font-heading font-bold text-lg flex items-center gap-2">
                <Clock className="w-5 h-5 text-brand-400" /> Rest Timer
              </div>
              <div className="text-xs text-gray-300">Rest between sets to optimize ATP recovery and muscle hypertrophy.</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {[30, 60, 90, 120].map((sec) => (
              <button
                key={sec}
                onClick={() => handleStartRestTimer(sec)}
                className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold border border-white/10 transition-colors"
              >
                {sec}s
              </button>
            ))}
            <button
              onClick={() => setTimerRunning(!timerRunning)}
              className="p-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white shadow-md transition-colors"
            >
              {timerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <button
              onClick={() => {
                setTimerRunning(false);
                setCurrentTimer(restTime);
              }}
              className="p-2.5 rounded-xl bg-gray-700 hover:bg-gray-600 text-gray-200 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* VIEW 1: Weekly Schedule */}
        {activeTab === 'schedule' && (
          <div className="space-y-6">
            {/* Days Selector Tabs */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
              {daysOfWeek.map((day) => (
                <button
                  key={day}
                  onClick={() => setSelectedDay(day)}
                  className={`px-5 py-3 rounded-2xl text-xs font-bold whitespace-nowrap transition-all ${
                    selectedDay === day
                      ? 'bg-brand-600 text-white shadow-md shadow-brand-600/30'
                      : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-800 hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
                >
                  {day}
                </button>
              ))}
            </div>

            {/* Selected Day Workout Details */}
            <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 sm:p-8 space-y-6 shadow-sm">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-4 border-b border-gray-100 dark:border-gray-800">
                <div>
                  <h2 className="font-heading font-extrabold text-2xl">{selectedDay} Routine</h2>
                  <p className="text-sm font-semibold text-brand-600 dark:text-brand-400 mt-0.5">
                    Focus: {currentDaySchedule.focus}
                  </p>
                </div>
                <span className="text-xs text-gray-500 font-semibold bg-gray-100 dark:bg-gray-800 px-3 py-1.5 rounded-xl">
                  {currentDaySchedule.exercises?.length || 0} Exercises Planned
                </span>
              </div>

              {currentDaySchedule.exercises?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentDaySchedule.exercises.map((ex: any, idx: number) => (
                    <div
                      key={idx}
                      className="p-5 rounded-2xl bg-gray-50 dark:bg-gray-800/40 border border-gray-200/80 dark:border-gray-700/60 card-shine flex flex-col justify-between"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="font-bold text-base text-gray-900 dark:text-white">{ex.name}</div>
                          <div className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Target: Compound Hypertrophy</div>
                        </div>
                        <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-brand-50 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300">
                          {ex.sets} Sets × {ex.reps}
                        </span>
                      </div>

                      <div className="flex items-center justify-between text-xs pt-3 border-t border-gray-200/60 dark:border-gray-700/60">
                        <span className="text-gray-500">Rest: {ex.rest}</span>
                        <button
                          onClick={() => {
                            setSelectedExName(ex.name);
                            setLogModalOpen(true);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-semibold flex items-center gap-1 transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" /> Log Weight
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-400 space-y-2">
                  <div className="text-4xl">😴</div>
                  <div className="font-bold text-lg text-gray-700 dark:text-gray-200">Rest & Recovery Day</div>
                  <div className="text-xs">Allow your muscle fibers to synthesize protein and rebuild stronger today!</div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* VIEW 2: Exercise Library */}
        {activeTab === 'library' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="relative flex-1 w-full">
                <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search exercises by name or muscle group..."
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-sm text-gray-900 dark:text-white outline-none"
                />
              </div>

              <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto scrollbar-none">
                {['All', 'Chest', 'Back', 'Legs', 'Shoulders', 'Arms', 'Core', 'Cardio'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      selectedCategory === cat
                        ? 'bg-brand-600 text-white'
                        : 'bg-white dark:bg-gray-900 text-gray-600 dark:text-gray-300 border border-gray-200 dark:border-gray-800'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredExercises.map((ex) => (
                <div
                  key={ex.id}
                  className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 card-shine flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-md bg-brand-50 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300">
                        {ex.category}
                      </span>
                      <span className="text-xs text-gray-400 font-medium">{ex.difficulty}</span>
                    </div>

                    <h3 className="font-heading font-bold text-lg text-gray-900 dark:text-white mb-1">{ex.name}</h3>
                    <div className="text-xs text-gray-500 mb-3">Equipment: {ex.equipment}</div>
                    <p className="text-xs text-gray-600 dark:text-gray-300 line-clamp-3 leading-relaxed mb-4">{ex.instructions}</p>
                  </div>

                  <button
                    onClick={() => {
                      setSelectedExName(ex.name);
                      setLogModalOpen(true);
                    }}
                    className="w-full py-2.5 rounded-xl bg-gray-100 dark:bg-gray-800 hover:bg-brand-600 hover:text-white text-xs font-semibold text-gray-800 dark:text-gray-200 transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Log Exercise
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* LOG WORKOUT MODAL */}
        {logModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="w-full max-w-md bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-6 space-y-4 shadow-2xl">
              <h3 className="font-heading font-bold text-xl">Log {selectedExName}</h3>
              <form onSubmit={handleLogExercise} className="space-y-4 text-sm">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Sets Completed</label>
                  <input
                    type="number"
                    value={logSets}
                    onChange={(e) => setLogSets(parseInt(e.target.value) || 1)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Reps Per Set</label>
                  <input
                    type="number"
                    value={logReps}
                    onChange={(e) => setLogReps(parseInt(e.target.value) || 1)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Weight Lifted (kg)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={logWeight}
                    onChange={(e) => setLogWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setLogModalOpen(false)}
                    className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-md"
                  >
                    Save Log
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
