import math
from typing import Dict, Any, List

def calculate_fitness_metrics(
    age: int,
    gender: str,
    height_cm: float,
    weight_kg: float,
    activity_level: str = "moderate",
    goal: str = "maintenance"
) -> Dict[str, Any]:
    # 1. BMI Calculation
    height_m = height_cm / 100.0
    bmi = round(weight_kg / (height_m ** 2), 1)

    if bmi < 18.5:
        bmi_category = "Underweight"
    elif 18.5 <= bmi < 24.9:
        bmi_category = "Normal weight"
    elif 25.0 <= bmi < 29.9:
        bmi_category = "Overweight"
    else:
        bmi_category = "Obese"

    # 2. BMR Calculation (Mifflin-St Jeor Equation)
    if gender.lower() == "male":
        bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age) + 5
    else:
        bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age) - 161
    bmr = round(bmr, 0)

    # 3. TDEE Activity Multipliers
    activity_multipliers = {
        "sedentary": 1.2,
        "light": 1.375,
        "moderate": 1.55,
        "active": 1.725,
        "very_active": 1.9
    }
    multiplier = activity_multipliers.get(activity_level.lower(), 1.55)
    tdee = round(bmr * multiplier, 0)

    # 4. Calorie Target based on Goal
    goal_clean = goal.lower().replace(" ", "_")
    if goal_clean in ["weight_loss", "fat_loss"]:
        target_calories = int(tdee - 450)
    elif goal_clean in ["muscle_gain", "strength"]:
        target_calories = int(tdee + 350)
    else: # maintenance or general fitness
        target_calories = int(tdee)

    target_calories = max(1200, target_calories) # Safe lower bound

    # 5. Macro Distribution (Protein, Carbs, Fats)
    if goal_clean in ["muscle_gain", "fat_loss"]:
        protein_per_kg = 2.0
    elif goal_clean == "weight_loss":
        protein_per_kg = 1.8
    else:
        protein_per_kg = 1.5

    protein_g = int(weight_kg * protein_per_kg)
    protein_calories = protein_g * 4

    # Fat: 25% of total calories
    fat_calories = target_calories * 0.25
    fats_g = int(fat_calories / 9)

    # Remaining calories for carbs
    carb_calories = target_calories - (protein_calories + fat_calories)
    carbs_g = max(50, int(carb_calories / 4))

    # 6. Water Intake Recommendation (35 ml per kg + extra for workout)
    water_ml = int((weight_kg * 35) + 500)

    return {
        "bmi": bmi,
        "bmi_category": bmi_category,
        "bmr": int(bmr),
        "tdee": int(tdee),
        "target_calories": target_calories,
        "protein_g": protein_g,
        "carbs_g": carbs_g,
        "fats_g": fats_g,
        "water_ml": water_ml
    }


def generate_personalized_workout_plan(
    goal: str,
    fitness_level: str,
    equipment: str,
    days_per_week: int
) -> Dict[str, Any]:
    goal_clean = goal.lower()
    equip_clean = equipment.lower()
    
    if days_per_week >= 5:
        split_type = "Push-Pull-Legs (5-Day Split)"
        schedule = [
            {"day": "Monday", "focus": "Push (Chest, Shoulders, Triceps)", "exercises": [
                {"name": "Barbell Bench Press" if equip_clean == "full_gym" else "Dumbbell Floor Press", "sets": 4, "reps": "8-10", "rest": "90s"},
                {"name": "Overhead Shoulder Press", "sets": 3, "reps": "10-12", "rest": "60s"},
                {"name": "Incline Dumbbell Press", "sets": 3, "reps": "10-12", "rest": "60s"},
                {"name": "Lateral Raises", "sets": 3, "reps": "12-15", "rest": "45s"},
                {"name": "Tricep Pushdowns" if equip_clean == "full_gym" else "Dips / Pushups", "sets": 3, "reps": "12-15", "rest": "45s"}
            ]},
            {"day": "Tuesday", "focus": "Pull (Back, Biceps, Rear Delts)", "exercises": [
                {"name": "Lat Pulldown" if equip_clean == "full_gym" else "Pull-ups / Inverted Rows", "sets": 4, "reps": "8-10", "rest": "90s"},
                {"name": "Bent-Over Dumbbell Rows", "sets": 4, "reps": "10-12", "rest": "60s"},
                {"name": "Face Pulls", "sets": 3, "reps": "12-15", "rest": "45s"},
                {"name": "Bicep Dumbbell Curls", "sets": 3, "reps": "10-12", "rest": "45s"},
                {"name": "Hammer Curls", "sets": 3, "reps": "12-15", "rest": "45s"}
            ]},
            {"day": "Wednesday", "focus": "Legs & Core", "exercises": [
                {"name": "Barbell Squats" if equip_clean == "full_gym" else "Goblet Squats", "sets": 4, "reps": "8-10", "rest": "90s"},
                {"name": "Romanian Deadlifts", "sets": 3, "reps": "10-12", "rest": "60s"},
                {"name": "Walking Lunges", "sets": 3, "reps": "12 per leg", "rest": "60s"},
                {"name": "Calf Raises", "sets": 4, "reps": "15-20", "rest": "45s"},
                {"name": "Hanging Leg Raises / Planks", "sets": 3, "reps": "15 reps / 60s hold", "rest": "45s"}
            ]},
            {"day": "Thursday", "focus": "Active Recovery / Light Cardio", "exercises": [
                {"name": "Brisk Walking / Cycling", "sets": 1, "reps": "30 mins", "rest": "N/A"},
                {"name": "Full Body Dynamic Stretching", "sets": 1, "reps": "15 mins", "rest": "N/A"}
            ]},
            {"day": "Friday", "focus": "Upper Body Hypertrophy", "exercises": [
                {"name": "Incline Bench Press", "sets": 4, "reps": "10-12", "rest": "60s"},
                {"name": "Seated Cable Rows", "sets": 4, "reps": "10-12", "rest": "60s"},
                {"name": "Dumbbell Arnold Press", "sets": 3, "reps": "10-12", "rest": "60s"},
                {"name": "Cable Bicep Curls", "sets": 3, "reps": "12-15", "rest": "45s"}
            ]},
            {"day": "Saturday", "focus": "Lower Body & HIIT", "exercises": [
                {"name": "Leg Press" if equip_clean == "full_gym" else "Bulgarian Split Squats", "sets": 4, "reps": "10-12", "rest": "60s"},
                {"name": "Hamstring Curls", "sets": 3, "reps": "12-15", "rest": "45s"},
                {"name": "HIIT Treadmill / Jump Rope", "sets": 10, "reps": "30s sprint / 30s rest", "rest": "30s"}
            ]},
            {"day": "Sunday", "focus": "Complete Rest", "exercises": []}
        ]
    else: # 3-4 Days Upper/Lower or Full Body
        split_type = "Upper / Lower Body Split (4-Day)"
        schedule = [
            {"day": "Monday", "focus": "Upper Body A", "exercises": [
                {"name": "Dumbbell Press", "sets": 4, "reps": "10", "rest": "60s"},
                {"name": "One-Arm Rows", "sets": 4, "reps": "10", "rest": "60s"},
                {"name": "Shoulder Press", "sets": 3, "reps": "12", "rest": "45s"},
                {"name": "Bicep Curls / Pushdowns", "sets": 3, "reps": "12", "rest": "45s"}
            ]},
            {"day": "Tuesday", "focus": "Lower Body A & Core", "exercises": [
                {"name": "Goblet Squats", "sets": 4, "reps": "10", "rest": "60s"},
                {"name": "Dumbbell Lunge", "sets": 3, "reps": "10 per leg", "rest": "60s"},
                {"name": "Glute Bridges", "sets": 3, "reps": "12", "rest": "45s"},
                {"name": "Plank Hold", "sets": 3, "reps": "45 seconds", "rest": "30s"}
            ]},
            {"day": "Wednesday", "focus": "Rest & Hydration", "exercises": []},
            {"day": "Thursday", "focus": "Upper Body B", "exercises": [
                {"name": "Push-ups", "sets": 4, "reps": "12-15", "rest": "45s"},
                {"name": "Lat Pulldown / Resistance Rows", "sets": 4, "reps": "12", "rest": "60s"},
                {"name": "Lateral Raises", "sets": 3, "reps": "15", "rest": "45s"}
            ]},
            {"day": "Friday", "focus": "Lower Body B & Cardio", "exercises": [
                {"name": "Dumbbell Deadlifts", "sets": 4, "reps": "10", "rest": "60s"},
                {"name": "Calf Raises", "sets": 4, "reps": "15", "rest": "45s"},
                {"name": "Incline Walk Cardio", "sets": 1, "reps": "25 mins", "rest": "N/A"}
            ]},
            {"day": "Saturday", "focus": "Rest", "exercises": []},
            {"day": "Sunday", "focus": "Rest", "exercises": []}
        ]

    return {
        "plan_name": f"{split_type} ({fitness_level.capitalize()} Level)",
        "split_type": split_type,
        "duration_weeks": 4,
        "weekly_schedule": schedule
    }


def generate_personalized_diet_plan(
    target_calories: int,
    protein_g: int,
    carbs_g: int,
    fats_g: int,
    dietary_preference: str
) -> Dict[str, Any]:
    pref = dietary_preference.lower()
    is_veg = pref in ["vegetarian", "vegan"]
    
    # Meal Calorie Breakdown: Breakfast 25%, Lunch 35%, Snack 15%, Dinner 25%
    b_cal = int(target_calories * 0.25)
    l_cal = int(target_calories * 0.35)
    s_cal = int(target_calories * 0.15)
    d_cal = int(target_calories * 0.25)

    if is_veg:
        meals = {
            "breakfast": {
                "name": "Oatmeal with Almonds, Whey/Soy Protein & Chia Seeds",
                "calories": b_cal,
                "protein_g": int(protein_g * 0.25),
                "carbs_g": int(carbs_g * 0.30),
                "fats_g": int(fats_g * 0.20),
                "suggestions": ["Rolled oats cooked in skim milk", "1 scoop Protein Powder", "10 Almonds", "1 tsp Chia seeds"]
            },
            "lunch": {
                "name": "Paneer Tikka / Tofu Bowl with Brown Rice, Dal & Salad",
                "calories": l_cal,
                "protein_g": int(protein_g * 0.35),
                "carbs_g": int(carbs_g * 0.35),
                "fats_g": int(fats_g * 0.35),
                "suggestions": ["150g Low-fat Paneer or Tofu", "1 cup Brown Rice / 2 Chapatis", "1 bowl Yellow Moong Dal", "Mixed Green Salad"]
            },
            "snacks": {
                "name": "Greek Yogurt with Berries & Roasted Chana",
                "calories": s_cal,
                "protein_g": int(protein_g * 0.15),
                "carbs_g": int(carbs_g * 0.15),
                "fats_g": int(fats_g * 0.15),
                "suggestions": ["150g Plain Greek Yogurt", "Handful of Roasted Bengal Gram (Chana)", "Green Tea"]
            },
            "dinner": {
                "name": "Soya Chunk Curry with Whole Wheat Chapati & Cucumber Raita",
                "calories": d_cal,
                "protein_g": int(protein_g * 0.25),
                "carbs_g": int(carbs_g * 0.20),
                "fats_g": int(fats_g * 0.30),
                "suggestions": ["50g Soya Chunks cooked in tomato gravy", "2 Multigrain Roti", "1 cup Cucumber Curd Raita"]
            }
        }
    else:
        meals = {
            "breakfast": {
                "name": "Whole Eggs & Whites Scramble with Toast & Avocado",
                "calories": b_cal,
                "protein_g": int(protein_g * 0.30),
                "carbs_g": int(carbs_g * 0.25),
                "fats_g": int(fats_g * 0.25),
                "suggestions": ["3 Whole Eggs + 2 Egg Whites", "2 Slices Whole Wheat Toast", "1/2 Avocado or 1 tsp Butter", "Black Coffee / Green Tea"]
            },
            "lunch": {
                "name": "Grilled Chicken Breast with Quinoa/Brown Rice & Steamed Broccoli",
                "calories": l_cal,
                "protein_g": int(protein_g * 0.40),
                "carbs_g": int(carbs_g * 0.35),
                "fats_g": int(fats_g * 0.30),
                "suggestions": ["180g Grilled Chicken Breast", "1 cup Cooked Brown Rice / Quinoa", "1 cup Steamed Broccoli & Carrots", "1 tsp Olive Oil drizzle"]
            },
            "snacks": {
                "name": "Whey Protein Shake & Handful of Walnuts",
                "calories": s_cal,
                "protein_g": int(protein_g * 0.15),
                "carbs_g": int(carbs_g * 0.15),
                "fats_g": int(fats_g * 0.20),
                "suggestions": ["1 Scoop Whey Protein with Water", "5-6 Walnut Halves", "1 Apple"]
            },
            "dinner": {
                "name": "Baked Fish / Lean Chicken Curry with Steamed Veggies & Chapati",
                "calories": d_cal,
                "protein_g": int(protein_g * 0.30),
                "carbs_g": int(carbs_g * 0.25),
                "fats_g": int(fats_g * 0.25),
                "suggestions": ["150g Fish (Rohu / Salmon / Tilapia) or Chicken", "2 Wheat Chapatis", "Sautéed Spinach & Peppers"]
            }
        }

    return {
        "target_calories": target_calories,
        "protein_g": protein_g,
        "carbs_g": carbs_g,
        "fats_g": fats_g,
        "meals": meals
    }
