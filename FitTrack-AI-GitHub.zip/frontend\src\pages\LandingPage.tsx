import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dumbbell, Sparkles, Activity, Utensils, TrendingUp, Bot, Shield, CheckCircle, ArrowRight, Zap, Award, Flame } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LandingPageProps {
  onOpenAuth: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onOpenAuth }) => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleStartPlan = () => {
    if (isAuthenticated) {
      navigate('/onboarding');
    } else {
      onOpenAuth();
    }
  };

  const features = [
    {
      icon: Sparkles,
      title: 'AI Plan Generation Engine',
      description: 'Generates customized workout splits, exact calorie targets, and macro ratios according to your goal, height, weight, and diet.'
    },
    {
      icon: Dumbbell,
      title: 'Personalized Workout Splits',
      description: 'Push-Pull-Legs, Upper/Lower, or Full Body routines with rest timers, sets/reps guidance, and equipment adapters.'
    },
    {
      icon: Utensils,
      title: 'Indian & Global Food Database',
      description: 'Track calories and macros across 50+ meals with specific Veg, Non-Veg, Vegan, and Indian dish options.'
    },
    {
      icon: Bot,
      title: 'FitBot AI Fitness Assistant',
      description: 'Context-aware 24/7 AI chatbot to clear exercise doubts, suggest meal alternatives, and guide your fat loss/muscle gain.'
    },
    {
      icon: TrendingUp,
      title: 'Visual Progress Analytics',
      description: 'Interactive line graphs tracking your weight loss, BMI trends, strength gains, and daily macro consistency.'
    },
    {
      icon: Award,
      title: 'Gamification & Streaks',
      description: 'Earn points, unlock achievement badges, maintain daily workout streaks, and compete on the platform leaderboard.'
    }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white transition-colors duration-200">
      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Glow background blobs */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-brand-500/20 to-emerald-400/20 blur-[100px] pointer-events-none rounded-full"></div>

        <div className="max-w-5xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 text-brand-700 dark:text-brand-300 text-xs sm:text-sm font-semibold mb-6 animate-in fade-in slide-in-from-top-4">
            <Sparkles className="w-4 h-4 text-brand-600 dark:text-brand-400" />
            <span>Next-Gen AI Fitness & Nutrition Ecosystem</span>
          </div>

          <h1 className="font-heading font-extrabold text-4xl sm:text-6xl lg:text-7xl tracking-tight leading-[1.1] mb-6">
            Your Personalized <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-brand-600 via-emerald-500 to-teal-500 bg-clip-text text-transparent">
              Fitness, Workout & Diet
            </span>{' '}
            Companion
          </h1>

          <p className="max-w-2xl mx-auto text-lg sm:text-xl text-gray-600 dark:text-gray-300 leading-relaxed mb-8">
            FitTrack AI calculates your BMR & TDEE, creates tailored workout splits, designs custom nutrition plans, and tracks your progress with machine learning insights.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={handleStartPlan}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-base shadow-xl shadow-brand-600/30 flex items-center justify-center gap-2 hover:scale-105 active:scale-95 transition-all"
            >
              <Zap className="w-5 h-5 fill-white" />
              Create Your Personalized Plan
            </button>
            <button
              onClick={() => navigate('/calculators')}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 font-semibold text-base border border-gray-200 dark:border-gray-700 shadow-sm hover:bg-gray-50 dark:hover:bg-gray-700/60 flex items-center justify-center gap-2 transition-all"
            >
              Explore Fitness Calculators
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Quick Metrics Bar */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
            <div className="p-4 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
              <div className="text-2xl font-extrabold text-brand-600 dark:text-brand-400">100%</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Personalized Goal Adaption</div>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
              <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">50+</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Indian & Global Foods</div>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
              <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400">24/7</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">FitBot AI Assistant</div>
            </div>
            <div className="p-4 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
              <div className="text-2xl font-extrabold text-purple-600 dark:text-purple-400">ML Model</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Target Calorie Predictor</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-white dark:bg-gray-900 border-y border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-14">
            <h2 className="font-heading font-bold text-3xl sm:text-4xl text-gray-900 dark:text-white">
              Everything You Need To Reach Your Target Body
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mt-3 text-base">
              Whether your goal is weight loss, muscle hypertrophy, fat loss, or strength building, FitTrack AI provides a complete data-driven system.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div
                  key={i}
                  className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-800/50 border border-gray-200/80 dark:border-gray-700/60 card-shine flex flex-col justify-between"
                >
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-brand-100 dark:bg-brand-900/50 text-brand-600 dark:text-brand-400 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-heading font-bold text-xl text-gray-900 dark:text-white mb-2">{f.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">{f.description}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Footer Banner */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-brand-600 to-emerald-600 text-white text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-heading font-extrabold text-3xl sm:text-4xl mb-4">Ready To Transform Your Health?</h2>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">
            Get your instant BMI, BMR, daily macro targets, and customized 4-week workout plan in under 2 minutes.
          </p>
          <button
            onClick={handleStartPlan}
            className="px-8 py-4 rounded-2xl bg-white text-brand-700 font-bold text-base shadow-lg hover:bg-gray-100 hover:scale-105 active:scale-95 transition-all"
          >
            Start Your Free Onboarding Now
          </button>
        </div>
      </section>
    </div>
  );
};
