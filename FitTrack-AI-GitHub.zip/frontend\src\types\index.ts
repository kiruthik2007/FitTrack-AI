export interface User {
  id: number;
  email: str;
  full_name: string;
  role: 'user' | 'trainer' | 'admin';
  is_active: boolean;
}

export interface UserProfile {
  id?: number;
  age: number;
  gender: string;
  height_cm: number;
  weight_kg: number;
  target_weight_kg?: number;
  fitness_goal: string;
  fitness_level: string;
  workout_preference: string;
  equipment: string;
  days_per_week: number;
  duration_mins: number;
  dietary_preference: string;
  food_cuisine_preference: string;
  allergies?: string;
  medical_conditions?: string;
  activity_level: string;
  bmi?: number;
  bmr?: number;
  tdee?: number;
  daily_calorie_target?: number;
  protein_target_g?: number;
  carbs_target_g?: number;
  fats_target_g?: number;
  water_target_ml?: number;
  streak_count?: number;
  points?: number;
}

export interface CalculatorResult {
  bmi: number;
  bmi_category: string;
  bmr: number;
  tdee: number;
  target_calories: number;
  protein_g: number;
  carbs_g: number;
  fats_g: number;
  water_ml: number;
}

export interface Exercise {
  id: number;
  name: string;
  category: string;
  muscle_group: string;
  equipment: string;
  difficulty: string;
  instructions?: string;
  video_url?: string;
}

export interface WorkoutExerciseItem {
  name: string;
  sets: number;
  reps: string;
  rest: string;
}

export interface WorkoutDaySchedule {
  day: string;
  focus: string;
  exercises: WorkoutExerciseItem[];
}

export interface WorkoutPlan {
  plan_name: string;
  split_type: string;
  duration_weeks: number;
  weekly_schedule: WorkoutDaySchedule[];
}

export interface FoodItem {
  id: number;
  name: string;
  category: string;
  cuisine: string;
  is_vegetarian: boolean;
  serving_size: string;
  calories: number;
  protein_g: number;
  carbs_g: number;
  fats_g: number;
}

export interface MealItem {
  name: string;
  calories: number;
  protein_g: number;
  carbs_g: number;
  fats_g: number;
  suggestions: string[];
}

export interface DietPlan {
  target_calories: number;
  protein_g: number;
  carbs_g: number;
  fats_g: number;
  meals: {
    breakfast: MealItem;
    lunch: MealItem;
    snacks: MealItem;
    dinner: MealItem;
  };
}

export interface DashboardSummary {
  user_name: string;
  streak_count: number;
  points: number;
  current_weight: number;
  target_weight: number;
  bmi: number;
  calories: {
    target: number;
    consumed: number;
    burned: number;
    remaining: number;
  };
  macros: {
    protein: { target: number; consumed: number };
    carbs: { target: number; consumed: number };
    fats: { target: number; consumed: number };
  };
  water_target_ml: number;
  todays_workouts: number;
  todays_meals: number;
}

export interface ChatMessageItem {
  sender: 'user' | 'ai';
  message: string;
  timestamp: string;
}
