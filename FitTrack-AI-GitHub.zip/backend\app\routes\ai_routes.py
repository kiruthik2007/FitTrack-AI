from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
import os
import joblib
import numpy as np

from app.database.connection import get_db
from app.models.schema import User, UserProfile, ChatMessage
from app.schemas.pydantic_models import ChatRequest, ChatResponse
from app.auth.security import get_current_user

router = APIRouter(prefix="/api/ai", tags=["AI & Machine Learning"])

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "ml", "saved_models", "fitness_recommendation_model.pkl")

# Load ML model if present
ml_model = None
if os.path.exists(MODEL_PATH):
    try:
        ml_model = joblib.load(MODEL_PATH)
    except Exception as e:
        print(f"Notice: ML model file could not be loaded ({e}). Fallback logic active.")


@router.post("/recommendation")
def get_ml_recommendation(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()
    if not profile:
        raise HTTPException(status_code=400, detail="Profile required for AI recommendation.")

    # Prepare features for ML Model
    # Features: [age, height_cm, weight_kg, bmi, days_per_week, duration_mins]
    features = np.array([[
        profile.age,
        profile.height_cm,
        profile.weight_kg,
        profile.bmi or 22.0,
        profile.days_per_week,
        profile.duration_mins
    ]])

    ai_insights = []

    if ml_model is not None:
        try:
            pred_calories, pred_protein = ml_model.predict(features)[0]
            ai_insights.append({
                "type": "ML_TARGET_PREDICTION",
                "title": "ML Model Predicted Optimal Targets",
                "description": f"Based on 1,000+ fitness profiles, our ML model predicts an optimal daily intake of ~{int(pred_calories)} kcal and ~{int(pred_protein)}g protein."
            })
        except Exception as e:
            pass

    # Profile & Progress Intelligence Analysis
    goal = profile.fitness_goal.lower()
    if "loss" in goal:
        ai_insights.append({
            "type": "FAT_LOSS_OPTIMIZATION",
            "title": "Optimal Fat Loss Deficit Verified",
            "description": f"Targeting a moderate deficit of {profile.daily_calorie_target} kcal with {profile.protein_target_g}g protein ensures max fat loss while preserving lean muscle mass."
        })
    elif "gain" in goal:
        ai_insights.append({
            "type": "HYPERTROPHY_FOCUS",
            "title": "Muscle Hypertrophy Surplus Active",
            "description": f"Consuming {profile.protein_target_g}g protein spread over 4 meals daily maximizes Muscle Protein Synthesis (MPS)."
        })

    # Hydration check
    ai_insights.append({
        "type": "HYDRATION_RECOVERY",
        "title": "Daily Water & Electrolyte Goal",
        "description": f"Drink at least {round((profile.water_target_ml or 3000)/1000, 1)} Liters of water daily to maintain peak performance during workouts."
    })

    return {
        "user_goal": profile.fitness_goal,
        "recommendations": ai_insights
    }


# FitBot AI Chatbot Endpoint
@router.post("/chat", response_model=ChatResponse)
def fitbot_chat(
    req: ChatRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    user_msg = req.message.strip().lower()
    profile = db.query(UserProfile).filter(UserProfile.user_id == current_user.id).first()

    # Domain Knowledge & Rules Engine for Contextual Safe Fitness Assistance
    reply = ""

    # Check medical / safety disclaimer triggers
    medical_keywords = ["pain", "injury", "chest pain", "dizziness", "disorder", "spine", "pregnant", "doctor"]
    if any(k in user_msg for k in medical_keywords):
        reply = (
            "⚠️ **Health & Safety Notice**: I noticed you mentioned a physical discomfort or medical condition. "
            "Please consult a qualified physician or licensed physiotherapist before attempting heavy workouts or restrictive diets. "
            "FitBot AI provides general fitness guidance and does not replace medical advice."
        )
    elif "fat loss" in user_msg or "lose weight" in user_msg or "belly fat" in user_msg:
        cals = profile.daily_calorie_target if profile else 1800
        prot = profile.protein_target_g if profile else 120
        reply = (
            f"🎯 **Fat Loss Strategy for {current_user.full_name.split()[0]}**:\n\n"
            f"1. **Calorie Deficit**: Aim for **{cals} kcal/day**.\n"
            f"2. **Protein Target**: Keep protein at **{prot}g/day** to protect your lean muscle.\n"
            f"3. **Workout Split**: 3-4 days of resistance training (Push/Pull/Legs) combined with 150 mins of weekly cardio.\n"
            f"4. **Hydration**: Drink 3-3.5L water daily."
        )
    elif "muscle gain" in user_msg or "build muscle" in user_msg or "bulk" in user_msg:
        cals = profile.daily_calorie_target if profile else 2500
        prot = profile.protein_target_g if profile else 140
        reply = (
            f"💪 **Muscle Gain Blueprint**:\n\n"
            f"1. **Calorie Surplus**: Consume around **{cals} kcal/day**.\n"
            f"2. **Protein**: Aim for **{prot}g protein/day** (Eggs, Chicken breast, Paneer, Tofu, Whey).\n"
            f"3. **Progressive Overload**: Focus on increasing weight or reps every 1-2 weeks on compound lifts (Squat, Bench, Deadlift, Overhead Press)."
        )
    elif "diet" in user_msg or "meal" in user_msg or "food" in user_msg or "protein" in user_msg:
        pref = profile.dietary_preference if profile else "general"
        reply = (
            f"🥗 **Nutrition Guidance ({pref.replace('_', ' ').capitalize()})**:\n\n"
            f"- **High-Protein Staples**: Paneer, Tofu, Soya Chunks, Moong Dal, Eggs, Chicken Breast, Fish, Greek Yogurt.\n"
            f"- **Complex Carbs**: Brown Rice, Oats, Quinoa, Whole Wheat Roti, Sweet Potatoes.\n"
            f"- **Healthy Fats**: Almonds, Walnuts, Chia seeds, Olive Oil.\n\n"
            f"Check out the **Diet & Nutrition Module** in FitTrack AI for your complete customized meal plan!"
        )
    elif "workout" in user_msg or "exercise" in user_msg or "routine" in user_msg:
        days = profile.days_per_week if profile else 4
        equip = profile.equipment if profile else "gym"
        reply = (
            f"🏋️ **Recommended Workout Frequency**:\n\n"
            f"- You are currently set to **{days} days/week** using **{equip.replace('_', ' ')}** equipment.\n"
            f"- Ensure 60-90 seconds rest between heavy compound sets and 45 seconds for isolation exercises.\n"
            f"You can view your detailed daily exercise schedule in the **Workout Module**!"
        )
    elif "creatine" in user_msg or "supplement" in user_msg or "whey" in user_msg:
        reply = (
            "💊 **Supplements Overview**:\n\n"
            "- **Whey Protein**: Convenient source of high-quality protein post-workout or between meals.\n"
            "- **Creatine Monohydrate**: 3-5g daily increases muscle cell hydration, strength, and power output.\n"
            "- **Multivitamins & Omega-3**: Great for general wellness, joint health, and immunity.\n\n"
            "Remember: Supplements complement a solid diet, but whole foods should form your primary nutrition!"
        )
    else:
        reply = (
            f"Hello {current_user.full_name.split()[0]}! 👋 I'm **FitBot AI**, your 24/7 fitness & nutrition assistant.\n\n"
            f"You can ask me questions like:\n"
            f"• *How can I lose belly fat safely?*\n"
            f"• *What foods should I eat for muscle gain?*\n"
            f"• *How much protein do I need daily?*\n"
            f"• *Is creatine monohydrate safe?*"
        )

    # Save to chat history
    msg_user = ChatMessage(user_id=current_user.id, sender="user", message=req.message)
    msg_ai = ChatMessage(user_id=current_user.id, sender="ai", message=reply)
    db.add(msg_user)
    db.add(msg_ai)
    db.commit()

    return {
        "reply": reply,
        "timestamp": datetime.utcnow()
    }
