import React, { useState } from 'react';
import { Calculator, Zap, Activity, Flame, Droplets, Dumbbell, Shield, ArrowRight } from 'lucide-react';
import { fitnessAPI } from '../services/api';
import { CalculatorResult } from '../types';

export const CalculatorsPage: React.FC = () => {
  const [age, setAge] = useState(25);
  const [gender, setGender] = useState('male');
  const [height, setHeight] = useState(175);
  const [weight, setWeight] = useState(75);
  const [activity, setActivity] = useState('moderate');
  const [goal, setGoal] = useState('fat_loss');

  // Standalone 1RM State
  const [liftWeight, setLiftWeight] = useState(100);
  const [liftReps, setLiftReps] = useState(5);

  const [result, setResult] = useState<CalculatorResult | null>({
    bmi: 24.5,
    bmi_category: 'Normal weight',
    bmr: 1730,
    tdee: 2681,
    target_calories: 2231,
    protein_g: 150,
    carbs_g: 223,
    fats_g: 61,
    water_ml: 3125
  });

  const handleCalculate = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fitnessAPI.calculate({
        age,
        gender,
        height_cm: height,
        weight_kg: weight,
        activity_level: activity,
        goal
      });
      setResult(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // Epley 1RM Formula: W * (1 + r / 30)
  const oneRepMax = Math.round(liftWeight * (1 + liftReps / 30));

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm">
          <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider mb-1">
            <Calculator className="w-4 h-4" /> Science-Based Algorithms
          </div>
          <h1 className="font-heading font-extrabold text-3xl">Fitness & Macro Calculators</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Calculate your exact BMI, BMR (Mifflin-St Jeor), TDEE, optimal calorie deficits, macros, and One-Rep Max.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Interactive Calculator Form */}
          <div className="lg:col-span-1 bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 sm:p-8 space-y-4 shadow-sm">
            <h3 className="font-heading font-bold text-xl mb-4">Calculate Calorie & Macro Target</h3>

            <form onSubmit={handleCalculate} className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Age</label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(parseInt(e.target.value) || 25)}
                    className="w-full px-3.5 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Gender</label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Height (cm)</label>
                  <input
                    type="number"
                    value={height}
                    onChange={(e) => setHeight(parseFloat(e.target.value) || 175)}
                    className="w-full px-3.5 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Weight (kg)</label>
                  <input
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(parseFloat(e.target.value) || 75)}
                    className="w-full px-3.5 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Activity Level</label>
                <select
                  value={activity}
                  onChange={(e) => setActivity(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                >
                  <option value="sedentary">Sedentary (Little or no exercise)</option>
                  <option value="light">Lightly Active (1-3 days/week)</option>
                  <option value="moderate">Moderately Active (3-5 days/week)</option>
                  <option value="active">Very Active (6-7 days/week)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Primary Fitness Goal</label>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                >
                  <option value="fat_loss">Fat Loss (-450 kcal deficit)</option>
                  <option value="weight_loss">Weight Loss (-500 kcal deficit)</option>
                  <option value="muscle_gain">Muscle Gain (+350 kcal surplus)</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-brand-600 hover:bg-brand-700 text-white font-bold shadow-md shadow-brand-600/20 transition-all flex items-center justify-center gap-2"
              >
                Calculate Results <Zap className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Right Column: Calculated Cards Breakdown */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Core Results Banner */}
            {result && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
                  <div className="text-xs font-semibold text-gray-400 uppercase">BMI Score</div>
                  <div className="text-3xl font-extrabold text-brand-600 dark:text-brand-400 mt-1">{result.bmi}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">{result.bmi_category}</div>
                </div>

                <div className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
                  <div className="text-xs font-semibold text-gray-400 uppercase">BMR (Metabolic)</div>
                  <div className="text-3xl font-extrabold text-blue-600 dark:text-blue-400 mt-1">{result.bmr}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">kcal at full rest</div>
                </div>

                <div className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
                  <div className="text-xs font-semibold text-gray-400 uppercase">TDEE (Burned)</div>
                  <div className="text-3xl font-extrabold text-purple-600 dark:text-purple-400 mt-1">{result.tdee}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">kcal daily burn</div>
                </div>

                <div className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
                  <div className="text-xs font-semibold text-gray-400 uppercase">Target Intake</div>
                  <div className="text-3xl font-extrabold text-amber-500 mt-1">{result.target_calories}</div>
                  <div className="text-xs text-gray-500 font-medium mt-0.5">kcal per day</div>
                </div>
              </div>
            )}

            {/* Macro Split Card */}
            {result && (
              <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
                <h3 className="font-heading font-bold text-xl">Recommended Macro Split</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-4 rounded-2xl bg-brand-50 dark:bg-brand-950/40 border border-brand-200 dark:border-brand-800">
                    <div className="text-xs font-bold text-brand-700 dark:text-brand-300">PROTEIN</div>
                    <div className="text-2xl font-extrabold text-brand-600 dark:text-brand-400 mt-1">{result.protein_g}g</div>
                    <div className="text-[11px] text-gray-500 mt-0.5">~{result.protein_g * 4} kcal</div>
                  </div>

                  <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800">
                    <div className="text-xs font-bold text-blue-700 dark:text-blue-300">CARBS</div>
                    <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400 mt-1">{result.carbs_g}g</div>
                    <div className="text-[11px] text-gray-500 mt-0.5">~{result.carbs_g * 4} kcal</div>
                  </div>

                  <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
                    <div className="text-xs font-bold text-amber-700 dark:text-amber-300">FATS</div>
                    <div className="text-2xl font-extrabold text-amber-500 mt-1">{result.fats_g}g</div>
                    <div className="text-[11px] text-gray-500 mt-0.5">~{result.fats_g * 9} kcal</div>
                  </div>
                </div>
              </div>
            )}

            {/* Standalone 1RM Calculator Box */}
            <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
              <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider">
                <Dumbbell className="w-4 h-4" /> Strength Benchmarking
              </div>
              <h3 className="font-heading font-bold text-xl">One-Rep Max (1RM) Calculator</h3>
              <p className="text-xs text-gray-500">Estimate your 100% max lift capability using the Epley Formula without maxing out dangerously.</p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Weight Lifted (kg)</label>
                  <input
                    type="number"
                    value={liftWeight}
                    onChange={(e) => setLiftWeight(parseFloat(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Reps Performed</label>
                  <input
                    type="number"
                    min="1"
                    max="15"
                    value={liftReps}
                    onChange={(e) => setLiftReps(parseInt(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none text-sm"
                  />
                </div>

                <div className="p-3.5 rounded-xl bg-gradient-to-r from-brand-600 to-emerald-500 text-white text-center">
                  <div className="text-[10px] uppercase font-bold text-white/80">Estimated 1RM</div>
                  <div className="text-2xl font-extrabold">{oneRepMax} kg</div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
