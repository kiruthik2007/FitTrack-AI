from abc import ABC, abstractmethod
from typing import Dict, Any, List
from datetime import datetime
import random

class BaseDeviceAdapter(ABC):
    @property
    @abstractmethod
    def provider_name(self) -> str:
        pass

    @abstractmethod
    def sync_data(self, user_id: int) -> Dict[str, Any]:
        pass


class AppleHealthAdapter(BaseDeviceAdapter):
    @property
    def provider_name(self) -> str:
        return "Apple Health"

    def sync_data(self, user_id: int) -> Dict[str, Any]:
        steps = random.randint(6500, 11500)
        active_calories = random.randint(320, 680)
        avg_heart_rate = random.randint(68, 76)
        sleep_hours = round(random.uniform(6.5, 8.2), 1)

        return {
            "provider": self.provider_name,
            "connected": True,
            "is_mock": True,
            "sync_timestamp": datetime.utcnow().isoformat(),
            "data": {
                "steps": steps,
                "active_calories": active_calories,
                "heart_rate_bpm": avg_heart_rate,
                "sleep_hours": sleep_hours,
                "active_minutes": random.randint(35, 75)
            },
            "credentials_required": ["HKHealthStore", "AuthorizationToken"]
        }


class GoogleHealthAdapter(BaseDeviceAdapter):
    @property
    def provider_name(self) -> str:
        return "Google Health Connect"

    def sync_data(self, user_id: int) -> Dict[str, Any]:
        steps = random.randint(7200, 12400)
        active_calories = random.randint(350, 710)
        avg_heart_rate = random.randint(65, 74)
        sleep_hours = round(random.uniform(7.0, 8.5), 1)

        return {
            "provider": self.provider_name,
            "connected": True,
            "is_mock": True,
            "sync_timestamp": datetime.utcnow().isoformat(),
            "data": {
                "steps": steps,
                "active_calories": active_calories,
                "heart_rate_bpm": avg_heart_rate,
                "sleep_hours": sleep_hours,
                "active_minutes": random.randint(40, 80)
            },
            "credentials_required": ["HealthConnectClientPermissions", "OAuth2Token"]
        }


class FitbitAdapter(BaseDeviceAdapter):
    @property
    def provider_name(self) -> str:
        return "Fitbit"

    def sync_data(self, user_id: int) -> Dict[str, Any]:
        return {
            "provider": self.provider_name,
            "connected": True,
            "is_mock": True,
            "sync_timestamp": datetime.utcnow().isoformat(),
            "data": {
                "steps": random.randint(8000, 13000),
                "active_calories": random.randint(400, 750),
                "heart_rate_bpm": random.randint(66, 75),
                "sleep_hours": 7.4,
                "resting_heart_rate": 62
            },
            "credentials_required": ["FitbitClientID", "FitbitClientSecret", "OAuthToken"]
        }


class GarminAdapter(BaseDeviceAdapter):
    @property
    def provider_name(self) -> str:
        return "Garmin Connect"

    def sync_data(self, user_id: int) -> Dict[str, Any]:
        return {
            "provider": self.provider_name,
            "connected": False,
            "is_mock": True,
            "sync_timestamp": None,
            "data": None,
            "credentials_required": ["GarminConnectConsumerKey", "ConsumerSecret"]
        }


class SamsungHealthAdapter(BaseDeviceAdapter):
    @property
    def provider_name(self) -> str:
        return "Samsung Health"

    def sync_data(self, user_id: int) -> Dict[str, Any]:
        return {
            "provider": self.provider_name,
            "connected": False,
            "is_mock": True,
            "sync_timestamp": None,
            "data": None,
            "credentials_required": ["SamsungHealthSDKKey"]
        }


class FitnessDeviceService:
    def __init__(self):
        self.adapters = {
            "apple_health": AppleHealthAdapter(),
            "google_health": GoogleHealthAdapter(),
            "fitbit": FitbitAdapter(),
            "garmin": GarminAdapter(),
            "samsung_health": SamsungHealthAdapter()
        }

    def list_providers(self) -> List[Dict[str, Any]]:
        return [
            {
                "id": key,
                "name": adapter.provider_name,
                "supported_metrics": ["steps", "calories", "heart_rate", "sleep"],
                "status": "connected" if key in ["apple_health", "google_health", "fitbit"] else "disconnected"
            }
            for key, adapter in self.adapters.items()
        ]

    def sync_provider(self, provider_id: str, user_id: int) -> Dict[str, Any]:
        adapter = self.adapters.get(provider_id)
        if not adapter:
            raise ValueError(f"Unsupported device provider: {provider_id}")
        return adapter.sync_data(user_id)
