$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:3000/")
$listener.Start()
Write-Host "FitTrack AI Web Server started at http://localhost:3000/"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        
        $filePath = "C:\Users\Pranav\.gemini\antigravity\scratch\fittrack-ai\app.html"
        $bytes = [System.IO.File]::ReadAllBytes($filePath)
        
        $response.ContentType = "text/html; charset=utf-8"
        $response.ContentLength64 = $bytes.Length
        $response.OutputStream.Write($bytes, 0, $bytes.Length)
        $response.Close()
    } catch {
        # ignore context errors on shutdown
    }
}
