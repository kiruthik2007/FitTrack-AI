from sqlalchemy import Column, Integer, String, Float, ForeignKey, DateTime, Text, JSON, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database.connection import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(String, default="user") # user, trainer, admin
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    profile = relationship("UserProfile", back_populates="user", uselist=False)
    workout_logs = relationship("WorkoutLog", back_populates="user")
    meal_logs = relationship("MealLog", back_populates="user")
    progress_logs = relationship("ProgressLog", back_populates="user")
    achievements = relationship("Achievement", back_populates="user")
    chat_messages = relationship("ChatMessage", back_populates="user")


class UserProfile(Base):
    __tablename__ = "user_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    age = Column(Integer, nullable=False)
    gender = Column(String, nullable=False) # male, female, other
    height_cm = Column(Float, nullable=False)
    weight_kg = Column(Float, nullable=False)
    target_weight_kg = Column(Float, nullable=True)
    
    fitness_goal = Column(String, nullable=False) # weight_loss, muscle_gain, fat_loss, maintenance, strength
    fitness_level = Column(String, default="beginner") # beginner, intermediate, advanced
    workout_preference = Column(String, default="gym") # gym, home, outdoor, hybrid
    equipment = Column(String, default="full_gym") # no_equipment, dumbbells, resistance_bands, full_gym
    days_per_week = Column(Integer, default=4)
    duration_mins = Column(Integer, default=45)

    dietary_preference = Column(String, default="non_vegetarian") # vegetarian, non_vegetarian, vegan, eggetarian
    food_cuisine_preference = Column(String, default="indian") # indian, western, custom
    allergies = Column(String, nullable=True)
    medical_conditions = Column(String, nullable=True)
    activity_level = Column(String, default="moderate") # sedentary, light, moderate, active, very_active

    # Calculated Targets
    bmi = Column(Float, nullable=True)
    bmr = Column(Float, nullable=True)
    tdee = Column(Float, nullable=True)
    daily_calorie_target = Column(Integer, nullable=True)
    protein_target_g = Column(Integer, nullable=True)
    carbs_target_g = Column(Integer, nullable=True)
    fats_target_g = Column(Integer, nullable=True)
    water_target_ml = Column(Integer, nullable=True)
    
    streak_count = Column(Integer, default=1)
    points = Column(Integer, default=100)

    user = relationship("User", back_populates="profile")


class Exercise(Base):
    __tablename__ = "exercises"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    category = Column(String, nullable=False) # Chest, Back, Legs, Shoulders, Arms, Core, Cardio
    muscle_group = Column(String, nullable=False)
    equipment = Column(String, nullable=False) # Dumbbell, Barbell, Machine, Bodyweight
    difficulty = Column(String, default="beginner")
    instructions = Column(Text, nullable=True)
    video_url = Column(String, nullable=True)


class WorkoutPlan(Base):
    __tablename__ = "workout_plans"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    plan_name = Column(String, nullable=False)
    split_type = Column(String, nullable=False) # Push-Pull-Legs, Upper-Lower, Full Body
    duration_weeks = Column(Integer, default=4)
    weekly_schedule = Column(JSON, nullable=False) # Structure containing days and exercises
    created_at = Column(DateTime, default=datetime.utcnow)


class WorkoutLog(Base):
    __tablename__ = "workout_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    date = Column(String, nullable=False) # YYYY-MM-DD
    exercise_name = Column(String, nullable=False)
    category = Column(String, default="General")
    sets_completed = Column(Integer, default=3)
    reps_completed = Column(Integer, default=10)
    weight_kg = Column(Float, default=0.0)
    duration_mins = Column(Integer, default=30)
    calories_burned = Column(Integer, default=150)
    notes = Column(String, nullable=True)

    user = relationship("User", back_populates="workout_logs")


class FoodItem(Base):
    __tablename__ = "food_items"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    category = Column(String, nullable=False) # Protein, Carbs, Fats, Vegetables, Fruits, Snacks
    cuisine = Column(String, default="Indian") # Indian, Global
    is_vegetarian = Column(Boolean, default=True)
    serving_size = Column(String, nullable=False) # e.g. "100g", "1 cup", "2 eggs"
    calories = Column(Float, nullable=False)
    protein_g = Column(Float, nullable=False)
    carbs_g = Column(Float, nullable=False)
    fats_g = Column(Float, nullable=False)


class MealLog(Base):
    __tablename__ = "meal_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    date = Column(String, nullable=False) # YYYY-MM-DD
    meal_type = Column(String, nullable=False) # Breakfast, Lunch, Snacks, Dinner
    food_name = Column(String, nullable=False)
    serving_quantity = Column(Float, default=1.0)
    calories = Column(Float, nullable=False)
    protein_g = Column(Float, nullable=False)
    carbs_g = Column(Float, nullable=False)
    fats_g = Column(Float, nullable=False)

    user = relationship("User", back_populates="meal_logs")


class ProgressLog(Base):
    __tablename__ = "progress_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    date = Column(String, nullable=False) # YYYY-MM-DD
    weight_kg = Column(Float, nullable=False)
    body_fat_pct = Column(Float, nullable=True)
    chest_cm = Column(Float, nullable=True)
    waist_cm = Column(Float, nullable=True)
    arms_cm = Column(Float, nullable=True)
    thighs_cm = Column(Float, nullable=True)
    notes = Column(Text, nullable=True)

    user = relationship("User", back_populates="progress_logs")


class Achievement(Base):
    __tablename__ = "achievements"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    title = Column(String, nullable=False)
    description = Column(String, nullable=False)
    icon_name = Column(String, default="Trophy")
    unlocked_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="achievements")


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    sender = Column(String, nullable=False) # user or ai
    message = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="chat_messages")
