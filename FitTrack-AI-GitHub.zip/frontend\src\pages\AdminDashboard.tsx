import React from 'react';
import { Shield, Users, Dumbbell, Utensils, Activity, Settings, CheckCircle, Database } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 text-purple-600 dark:text-purple-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <Shield className="w-4 h-4" /> System Administration
            </div>
            <h1 className="font-heading font-extrabold text-3xl">Admin Control Panel</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Manage platform users, seed database entries, audit exercises, and view platform health.
            </p>
          </div>
          <span className="px-3 py-1.5 rounded-xl bg-purple-100 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 font-bold text-xs">
            ADMIN ROLE ACTIVE
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
            <div className="text-xs font-semibold text-gray-400 uppercase">Total Active Users</div>
            <div className="text-3xl font-extrabold text-brand-600 mt-1">1,248</div>
            <div className="text-xs text-emerald-500 font-semibold mt-1">+14% this month</div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
            <div className="text-xs font-semibold text-gray-400 uppercase">Exercises in DB</div>
            <div className="text-3xl font-extrabold text-blue-600 mt-1">32 Items</div>
            <div className="text-xs text-gray-500 font-semibold mt-1">Categorized & verified</div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
            <div className="text-xs font-semibold text-gray-400 uppercase">Food Database</div>
            <div className="text-3xl font-extrabold text-amber-500 mt-1">54 Items</div>
            <div className="text-xs text-gray-500 font-semibold mt-1">Indian & Global</div>
          </div>

          <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm">
            <div className="text-xs font-semibold text-gray-400 uppercase">ML Model Accuracy</div>
            <div className="text-3xl font-extrabold text-purple-600 mt-1">94.2%</div>
            <div className="text-xs text-purple-500 font-semibold mt-1">RandomForest Regressor</div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 sm:p-8 space-y-4">
          <h3 className="font-heading font-bold text-xl">Platform Users Management</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-gray-100 dark:border-gray-800 text-xs font-bold text-gray-500 uppercase">
                  <th className="pb-3">User Name</th>
                  <th className="pb-3">Email</th>
                  <th className="pb-3">Role</th>
                  <th className="pb-3">Goal</th>
                  <th className="pb-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800 text-xs">
                <tr>
                  <td className="py-3 font-semibold">System Admin</td>
                  <td className="py-3 text-gray-500">admin@fittrack.com</td>
                  <td className="py-3"><span className="px-2 py-0.5 rounded bg-purple-100 text-purple-700 font-bold">Admin</span></td>
                  <td className="py-3">Maintenance</td>
                  <td className="py-3"><span className="text-gray-400">System Protected</span></td>
                </tr>
                <tr>
                  <td className="py-3 font-semibold">Alex Johnson</td>
                  <td className="py-3 text-gray-500">demo@fittrack.com</td>
                  <td className="py-3"><span className="px-2 py-0.5 rounded bg-brand-100 text-brand-700 font-bold">User</span></td>
                  <td className="py-3">Fat Loss & Recomp</td>
                  <td className="py-3"><button className="text-brand-600 hover:underline">Manage Profile</button></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
