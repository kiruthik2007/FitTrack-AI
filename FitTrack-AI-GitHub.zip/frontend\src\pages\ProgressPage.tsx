import React, { useState, useEffect } from 'react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { TrendingUp, Plus, Calendar, Activity, Award, Scale } from 'lucide-react';
import { fitnessAPI } from '../services/api';

export const ProgressPage: React.FC = () => {
  const [progressLogs, setProgressLogs] = useState<any[]>([]);
  const [logModalOpen, setLogModalOpen] = useState(false);
  const [weight, setWeight] = useState(78.0);
  const [bodyFat, setBodyFat] = useState(19.5);
  const [waist, setWaist] = useState(84.0);

  const fetchLogs = async () => {
    try {
      const res = await fitnessAPI.getProgressLogs();
      if (res.data && res.data.length > 0) {
        setProgressLogs(res.data);
      } else {
        // Fallback demo dataset for rich immediate rendering
        setProgressLogs([
          { date: 'Jul 01', weight_kg: 82.0, body_fat_pct: 22.0, waist_cm: 88.0 },
          { date: 'Jul 07', weight_kg: 81.2, body_fat_pct: 21.5, waist_cm: 87.2 },
          { date: 'Jul 14', weight_kg: 80.1, body_fat_pct: 20.8, waist_cm: 86.0 },
          { date: 'Jul 21', weight_kg: 79.0, body_fat_pct: 20.0, waist_cm: 85.0 },
          { date: 'Jul 27', weight_kg: 78.0, body_fat_pct: 19.4, waist_cm: 84.0 }
        ]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleAddProgress = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fitnessAPI.logProgress({
        date: new Date().toISOString().split('T')[0],
        weight_kg: weight,
        body_fat_pct: bodyFat,
        waist_cm: waist
      });
      setLogModalOpen(false);
      fetchLogs();
      alert("Progress weigh-in recorded successfully!");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-8 px-4 sm:px-6 lg:px-8 text-gray-900 dark:text-white transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="bg-white dark:bg-gray-900 p-6 sm:p-8 rounded-3xl border border-gray-200 dark:border-gray-800 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-brand-600 dark:text-brand-400 font-semibold text-xs uppercase tracking-wider mb-1">
              <TrendingUp className="w-4 h-4" /> Visual Analytics & History
            </div>
            <h1 className="font-heading font-extrabold text-3xl">Progress Tracking Dashboard</h1>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Monitor your body weight, body fat %, and measurement transformations over time.
            </p>
          </div>

          <button
            onClick={() => setLogModalOpen(true)}
            className="px-5 py-3 rounded-2xl bg-brand-600 hover:bg-brand-700 text-white font-bold text-sm shadow-md shadow-brand-600/20 flex items-center gap-2 transition-all"
          >
            <Plus className="w-4 h-4" /> Log Weigh-In
          </button>
        </div>

        {/* Visual Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Chart 1: Weight Loss Progress Line Graph */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-heading font-bold text-xl">Weight Progress (kg)</h3>
                <p className="text-xs text-gray-400">Total weight change over recorded periods</p>
              </div>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-3 py-1 rounded-full">
                -4.0 kg Lost Total
              </span>
            </div>

            <div className="h-64 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={progressLogs}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
                  <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
                  <YAxis domain={['dataMin - 2', 'dataMax + 2']} stroke="#9CA3AF" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151', borderRadius: '12px', color: '#fff' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="weight_kg"
                    stroke="#16a34a"
                    strokeWidth={3}
                    dot={{ r: 5, fill: '#16a34a' }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Body Fat % Trends */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-heading font-bold text-xl">Body Fat % Trend</h3>
                <p className="text-xs text-gray-400">Estimated body fat percentage reduction</p>
              </div>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 dark:bg-blue-950 px-3 py-1 rounded-full">
                19.4% Current
              </span>
            </div>

            <div className="h-64 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={progressLogs}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.2} />
                  <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
                  <YAxis domain={['dataMin - 1', 'dataMax + 1']} stroke="#9CA3AF" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#111827', border: '1px solid #374151', borderRadius: '12px', color: '#fff' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="body_fat_pct"
                    stroke="#6366f1"
                    strokeWidth={3}
                    dot={{ r: 5, fill: '#6366f1' }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* History Log Table */}
        <div className="bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 sm:p-8 shadow-sm space-y-4">
          <h3 className="font-heading font-bold text-xl">Historical Weigh-In Log</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-gray-100 dark:border-gray-800 text-xs font-bold text-gray-500 uppercase tracking-wider">
                  <th className="pb-3">Date</th>
                  <th className="pb-3">Weight (kg)</th>
                  <th className="pb-3">Body Fat %</th>
                  <th className="pb-3">Waist (cm)</th>
                  <th className="pb-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
                {progressLogs.map((log, idx) => (
                  <tr key={idx} className="hover:bg-gray-50 dark:hover:bg-gray-800/40 transition-colors">
                    <td className="py-3.5 font-semibold text-gray-900 dark:text-white">{log.date}</td>
                    <td className="py-3.5 text-brand-600 dark:text-brand-400 font-bold">{log.weight_kg} kg</td>
                    <td className="py-3.5">{log.body_fat_pct || '19.5'}%</td>
                    <td className="py-3.5">{log.waist_cm || '85'} cm</td>
                    <td className="py-3.5">
                      <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-600 font-semibold">
                        Progressing
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* LOG WEIGH IN MODAL */}
        {logModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
            <div className="w-full max-w-md bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-6 space-y-4 shadow-2xl">
              <h3 className="font-heading font-bold text-xl">Record Body Progress</h3>
              <form onSubmit={handleAddProgress} className="space-y-4 text-sm">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Body Weight (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={weight}
                    onChange={(e) => setWeight(parseFloat(e.target.value) || 70)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Body Fat % (Optional)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={bodyFat}
                    onChange={(e) => setBodyFat(parseFloat(e.target.value) || 15)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">Waist Circumference (cm)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={waist}
                    onChange={(e) => setWaist(parseFloat(e.target.value) || 80)}
                    className="w-full px-4 py-2.5 rounded-xl bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setLogModalOpen(false)}
                    className="flex-1 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold shadow-md"
                  >
                    Save Weigh-In
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
